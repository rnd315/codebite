# Color System Overhaul: Cyan + Purple

Replace the current neon-green primary with an Electric Cyan primary and Neon Purple accent, across both dark (default) and light themes. Green is reserved strictly for success/completed states.

## New token palette

All colors defined as semantic tokens in `src/styles.css` (oklch). Components keep using `text-primary`, `bg-accent`, etc. — no hard-coded Tailwind color classes.

### Dark mode (default — Cyberpunk)
- `--background`: deep slate/navy (~slate-950)
- `--foreground`: near-white slate
- `--card` / `--surface-glass`: translucent slate-900
- `--primary`: Electric Cyan (~cyan-400) — glowing traces, `> boot_module` CTA, active text, active node ring
- `--accent`: Neon Purple (~fuchsia-500 / purple-400) — token (💠) icon, minor decorative highlights
- `--success` (new token): Emerald-400 — completed nodes, correct-answer states only
- `--glow-primary`: cyan glow
- `--glow-accent`: purple glow
- `--streak`: kept warm amber for the uptime/streak dot

### Light mode (Daylight Editor)
- `--background`: cool light gray (~slate-50), NOT pure white
- `--foreground`: deep slate
- `--card`: white with subtle slate tint
- `--primary`: deeper cyan (~cyan-700) for WCAG AA contrast on light bg
- `--accent`: deep indigo (~indigo-700)
- `--success`: emerald-700
- Glows softened for light surfaces

## Component-level changes

Only swap colors — no layout or copy changes.

- `TopNav.tsx`: Hexagon token icon → `text-accent fill-accent/30` (purple). Streak Zap stays amber. Avatar gradient → `from-primary to-accent` (cyan→purple).
- `Hero.tsx`: `> boot_module` button → primary (cyan); secondary copy and decorative bits → accent (purple).
- `SkillConstellation.tsx`:
  - Active node (MOD_01): primary cyan glow + ring
  - Locked nodes (MOD_02, MOD_03): muted slate, padlock stays
  - Completed state (if any): `--success` emerald
  - Connecting traces / dash-flow lines: primary cyan
- `CommunityFeed.tsx` ("Debugger's Guild"): `>_ Debug & Earn` button → primary cyan; 💠 Token glyph → accent purple.
- `RightRail.tsx`: progress/active accents → primary; token/decorative pings → accent; any "completed" checkmarks → success.
- `BackgroundFX.tsx`: radial halos pick up new `--glow-primary` (cyan) and `--glow-accent` (purple) automatically via tokens.
- `Logo.tsx`: gradient updated to cyan→purple via tokens.

## Technical notes

- Add a `--success` / `--color-success` token pair in `@theme inline` so `text-success` / `bg-success` work in Tailwind v4.
- Keep `:root` (light) and `.dark` blocks in `src/styles.css` as the single source of truth. Components stay token-based, so `dark:` modifiers are mostly unnecessary — the token swap handles theme transitions. Use `dark:` modifiers only in the few spots where a literal Tailwind shade is currently hard-coded.
- Verify WCAG AA: light-mode cyan-700 on slate-50 ≈ 5.4:1 ✓; indigo-700 on slate-50 ≈ 8.6:1 ✓.
- After edits, screenshot both themes in the preview to confirm the green is fully gone and contrast looks right.

## Files touched

- `src/styles.css` (token palette — primary edit)
- `src/components/codebite/TopNav.tsx`
- `src/components/codebite/Hero.tsx`
- `src/components/codebite/SkillConstellation.tsx`
- `src/components/codebite/CommunityFeed.tsx`
- `src/components/codebite/RightRail.tsx`
- `src/components/codebite/Logo.tsx`
