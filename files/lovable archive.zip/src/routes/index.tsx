import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { TopNav } from "@/components/codebite/TopNav";
import { Hero } from "@/components/codebite/Hero";
import { SkillConstellation } from "@/components/codebite/SkillConstellation";
import { CommunityFeed } from "@/components/codebite/CommunityFeed";
import { RightRail } from "@/components/codebite/RightRail";
import { BackgroundFX } from "@/components/codebite/BackgroundFX";
import type { View } from "@/components/codebite/ViewSwitcher";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const [lang, setLang] = useState<"cpp" | "py">("cpp");
  const [uiLang, setUiLang] = useState<"EN" | "RO">("EN");
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [view, setView] = useState<View>("learn");

  useEffect(() => {
    const stored =
      typeof window !== "undefined"
        ? (localStorage.getItem("cb-theme") as "light" | "dark" | null)
        : null;
    if (stored) setTheme(stored);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    if (typeof window !== "undefined") localStorage.setItem("cb-theme", theme);
  }, [theme]);

  return (
    <div className="relative min-h-screen text-foreground">
      <BackgroundFX />

      <TopNav
        lang={lang}
        setLang={setLang}
        uiLang={uiLang}
        setUiLang={setUiLang}
        theme={theme}
        toggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
        view={view}
        setView={setView}
        streak={12}
        tokens={5}
        maxTokens={5}
      />

      <main className="mx-auto max-w-7xl px-4 py-8 lg:px-8">
        <Hero uiLang={uiLang} view={view} />

        <div className="mt-10">
          {view === "learn" ? (
            <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
              <SkillConstellation uiLang={uiLang} />
              <div className="lg:sticky lg:top-28 lg:self-start">
                <RightRail uiLang={uiLang} />
              </div>
            </div>
          ) : (
            <CommunityFeed uiLang={uiLang} lang={lang} />
          )}
        </div>

        <footer className="mt-16 flex flex-wrap items-center justify-between gap-2 border-t border-border/60 pt-6 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
          <span>codebite · neo-shell · build 0.1.0</span>
          <span>
            {lang === "cpp" ? "C++" : "Python"} · {uiLang} · {view === "learn" ? "learn" : "community"} ·
            <span className="ml-1 inline-block h-1.5 w-1.5 translate-y-[-1px] animate-pulse-soft rounded-full bg-primary align-middle" />
          </span>
        </footer>
      </main>
    </div>
  );
}
