export function Logo() {
  return (
    <a href="/" className="group flex items-center gap-2.5">
      <div className="relative grid h-9 w-9 place-items-center rounded-xl glass">
        <span
          className="font-mono text-base font-bold leading-none text-gradient"
          aria-hidden
        >
          {`{·}`}
        </span>
        <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-accent shadow-[0_0_10px_var(--glow-accent)]" />
      </div>
      <div className="flex flex-col leading-none">
        <span className="font-mono text-[15px] font-bold tracking-tight text-foreground">
          code<span className="text-accent">bite</span>
          <span className="ml-0.5 inline-block h-1.5 w-1.5 translate-y-[-2px] animate-pulse-soft rounded-full bg-accent align-middle" />
        </span>
        <span className="font-mono text-[9px] uppercase tracking-[0.28em] text-muted-foreground">
          v0.1 · dev-shell
        </span>
      </div>
    </a>
  );
}
