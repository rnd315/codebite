import { cn } from "@/lib/utils";

interface PillToggleProps<T extends string> {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  label?: string;
}

export function PillToggle<T extends string>({ options, value, onChange, label }: PillToggleProps<T>) {
  return (
    <div className="flex items-center gap-2">
      {label && (
        <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground md:inline">
          {label}
        </span>
      )}
      <div className="relative inline-flex rounded-full glass p-0.5">
        {options.map((opt) => {
          const active = opt.value === value;
          return (
            <button
              key={opt.value}
              onClick={() => onChange(opt.value)}
              className={cn(
                "relative z-10 rounded-full px-3 py-1 text-xs font-semibold tracking-wide transition-all",
                active
                  ? "bg-foreground text-background shadow-[0_0_20px_-6px_var(--glow-primary)]"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
