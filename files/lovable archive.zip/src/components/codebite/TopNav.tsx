import { Zap, Hexagon, Moon, Sun } from "lucide-react";
import { Logo } from "./Logo";
import { PillToggle } from "./PillToggle";
import { ViewSwitcher, type View } from "./ViewSwitcher";

interface TopNavProps {
  lang: "cpp" | "py";
  setLang: (v: "cpp" | "py") => void;
  uiLang: "EN" | "RO";
  setUiLang: (v: "EN" | "RO") => void;
  theme: "light" | "dark";
  toggleTheme: () => void;
  view: View;
  setView: (v: View) => void;
  streak: number;
  tokens: number;
  maxTokens: number;
}

export function TopNav({
  lang, setLang, uiLang, setUiLang, theme, toggleTheme, view, setView,
  streak, tokens, maxTokens,
}: TopNavProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 lg:px-8">
        <div className="flex items-center gap-5">
          <Logo />
          <div className="hidden items-center gap-2 md:flex">
            <PillToggle
              label="LANG"
              value={lang}
              onChange={setLang}
              options={[
                { value: "cpp", label: "C++" },
                { value: "py", label: "Python" },
              ]}
            />
            <PillToggle
              label="UI"
              value={uiLang}
              onChange={setUiLang}
              options={[
                { value: "EN", label: "EN" },
                { value: "RO", label: "RO" },
              ]}
            />
          </div>
        </div>

        <div className="hidden lg:block">
          <ViewSwitcher value={view} onChange={setView} uiLang={uiLang} />
        </div>

        <div className="flex items-center gap-2">
          <Stat icon={<Zap className="h-3.5 w-3.5 text-accent fill-accent" strokeWidth={2} />} label="UPTIME" value={`${streak}d`} />
          <Stat icon={<Hexagon className="h-3.5 w-3.5 text-primary fill-primary/30" strokeWidth={2.25} />} label="TOKENS" value={`${tokens}/${maxTokens}`} />
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="grid h-9 w-9 place-items-center rounded-full glass text-foreground transition-colors hover:bg-secondary"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <div className="relative grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-xs font-black text-background ring-2 ring-background">
            A
            <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-streak ring-2 ring-background" />
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-2 border-t border-border/60 px-4 py-2 lg:hidden">
        <ViewSwitcher value={view} onChange={setView} uiLang={uiLang} />
      </div>
      <div className="flex items-center justify-center gap-2 border-t border-border/60 px-4 py-2 md:hidden">
        <PillToggle value={lang} onChange={setLang} options={[{ value: "cpp", label: "C++" }, { value: "py", label: "Python" }]} />
        <PillToggle value={uiLang} onChange={setUiLang} options={[{ value: "EN", label: "EN" }, { value: "RO", label: "RO" }]} />
      </div>
    </header>
  );
}

function Stat({ icon, value, label }: { icon: React.ReactNode; value: React.ReactNode; label: string }) {
  return (
    <div className="hidden items-center gap-1.5 rounded-md glass px-2.5 py-1.5 sm:inline-flex">
      {icon}
      <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      <span className="font-mono text-xs font-bold text-foreground">{value}</span>
    </div>
  );
}
