import { ChevronRight, Lock, Play, Server, Terminal } from "lucide-react";
import { cn } from "@/lib/utils";

type Status = "active" | "locked";

interface MacroModule {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  status: Status;
  meta: { label: string; value: string }[];
  progress: number; // 0..100
}

const modulesEN: MacroModule[] = [
  {
    id: "m1",
    code: "MOD_01",
    title: "FOUNDATIONS",
    subtitle: "Variables · I/O · Branches",
    status: "active",
    progress: 64,
    meta: [
      { label: "UNITS", value: "12" },
      { label: "XP", value: "1.4K" },
      { label: "ETA", value: "3h" },
    ],
  },
  {
    id: "m2",
    code: "MOD_02",
    title: "LOOPS & LOGIC",
    subtitle: "While · For · Arrays",
    status: "locked",
    progress: 0,
    meta: [
      { label: "UNITS", value: "18" },
      { label: "XP", value: "2.1K" },
      { label: "ETA", value: "5h" },
    ],
  },
  {
    id: "m3",
    code: "MOD_03",
    title: "ALGORITHMS",
    subtitle: "Sorting · Searching",
    status: "locked",
    progress: 0,
    meta: [
      { label: "UNITS", value: "24" },
      { label: "XP", value: "3.6K" },
      { label: "ETA", value: "9h" },
    ],
  },
];

const modulesRO: MacroModule[] = [
  {
    id: "m1",
    code: "MOD_01",
    title: "FUNDAMENTE",
    subtitle: "Variabile · I/O · Ramificări",
    status: "active",
    progress: 64,
    meta: [
      { label: "UNITĂȚI", value: "12" },
      { label: "XP", value: "1.4K" },
      { label: "ETA", value: "3h" },
    ],
  },
  {
    id: "m2",
    code: "MOD_02",
    title: "BUCLE & LOGICĂ",
    subtitle: "While · For · Vectori",
    status: "locked",
    progress: 0,
    meta: [
      { label: "UNITĂȚI", value: "18" },
      { label: "XP", value: "2.1K" },
      { label: "ETA", value: "5h" },
    ],
  },
  {
    id: "m3",
    code: "MOD_03",
    title: "ALGORITMI",
    subtitle: "Sortare · Căutare",
    status: "locked",
    progress: 0,
    meta: [
      { label: "UNITĂȚI", value: "24" },
      { label: "XP", value: "3.6K" },
      { label: "ETA", value: "9h" },
    ],
  },
];

export function SkillConstellation({ uiLang }: { uiLang: "EN" | "RO" }) {
  const modules = uiLang === "EN" ? modulesEN : modulesRO;
  const cleared = uiLang === "EN" ? "CLEARED" : "FINALIZAT";
  const lockedLabel = uiLang === "EN" ? "SECTOR LOCKED" : "SECTOR BLOCAT";
  const unlockHint =
    uiLang === "EN"
      ? "Clear the previous module to decrypt this sector"
      : "Termină modulul anterior pentru a decripta acest sector";
  const bootLabel = uiLang === "EN" ? "> boot_module" : "> pornește_modul";
  const activeLabel = uiLang === "EN" ? "ACTIVE" : "ACTIV";
  const lockedPill = uiLang === "EN" ? "LOCKED" : "BLOCAT";

  return (
    <section className="relative">
      <div className="mb-5 flex items-end justify-between">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
            ~/skill-tree
          </div>
          <h2 className="mt-1 font-mono text-lg font-bold text-foreground">
            <span className="text-accent">$</span> tree --macro
          </h2>
        </div>
        <div className="text-right">
          <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
            {cleared}
          </div>
          <div className="font-mono text-sm font-bold text-foreground">01 / 03</div>
        </div>
      </div>

      <div className="space-y-2">
        {modules.map((mod, idx) => {
          const next = modules[idx + 1];
          return (
            <div key={mod.id}>
              <MacroModuleCard
                mod={mod}
                lockedLabel={lockedLabel}
                unlockHint={unlockHint}
                bootLabel={bootLabel}
                activeLabel={activeLabel}
                lockedPill={lockedPill}
              />
              {next && <BusConnector />}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function MacroModuleCard({
  mod,
  lockedLabel,
  unlockHint,
  bootLabel,
  activeLabel,
  lockedPill,
}: {
  mod: MacroModule;
  lockedLabel: string;
  unlockHint: string;
  bootLabel: string;
  activeLabel: string;
  lockedPill: string;
}) {
  const isActive = mod.status === "active";

  return (
    <div className="relative">
      <div
        className={cn(
          "relative overflow-hidden rounded-2xl border bg-background/60 transition-colors",
          isActive ? "border-accent/40" : "border-hairline"
        )}
      >
        {/* faint grid */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "linear-gradient(to right, var(--grid-line) 1px, transparent 1px), linear-gradient(to bottom, var(--grid-line) 1px, transparent 1px)",
            backgroundSize: "24px 24px",
          }}
        />

        {/* glow for active */}
        {isActive && (
          <div
            aria-hidden
            className="pointer-events-none absolute -inset-px rounded-2xl opacity-60 blur-2xl"
            style={{ background: "var(--glow-accent)" }}
          />
        )}

        {/* rack header strip */}
        <div className="relative flex items-center justify-between gap-2 border-b border-hairline bg-secondary/30 px-4 py-2">
          <div className="flex items-center gap-2">
            <Server className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2} />
            <span className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              rack / {mod.code.toLowerCase()}
            </span>
          </div>
          <StatusPill status={mod.status} activeLabel={activeLabel} lockedPill={lockedPill} />
        </div>

        {/* main row */}
        <div className="relative grid gap-6 p-5 md:grid-cols-[auto_1fr_auto] md:items-center">
          {/* Left: big mainframe badge */}
          <MainframeBadge code={mod.code} active={isActive} />

          {/* Center: title + subtitle + progress */}
          <div className="min-w-0">
            <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-accent">
              {mod.code} //
            </div>
            <h3 className="mt-1 font-mono text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              {mod.title}
            </h3>
            <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              {mod.subtitle}
            </p>

            {/* meta strip */}
            <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
              {mod.meta.map((m) => (
                <div key={m.label} className="flex items-baseline gap-1.5">
                  <span className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
                    {m.label}
                  </span>
                  <span className="font-mono text-sm font-bold text-foreground">{m.value}</span>
                </div>
              ))}
            </div>

            {/* capacity meter */}
            <div className="mt-4 flex items-center gap-3">
              <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-secondary/60">
                <div
                  className={cn(
                    "h-full rounded-full transition-all",
                    isActive ? "bg-accent" : "bg-hairline"
                  )}
                  style={{ width: `${mod.progress}%` }}
                />
              </div>
              <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
                {String(mod.progress).padStart(2, "0")}%
              </span>
            </div>
          </div>

          {/* Right: 1U LED rack + CTA */}
          <div className="flex w-full flex-col gap-3 md:w-56">
            <LedRack active={isActive} />
            {isActive ? (
              <button className="group inline-flex items-center justify-between gap-2 rounded-md bg-accent px-3 py-2 font-mono text-[11px] font-bold uppercase tracking-[0.18em] text-accent-foreground transition-all hover:shadow-[0_0_28px_-4px_var(--glow-accent)]">
                <span className="inline-flex items-center gap-2">
                  <Play className="h-3 w-3 fill-accent-foreground" strokeWidth={0} />
                  {bootLabel}
                </span>
                <ChevronRight className="h-3.5 w-3.5" strokeWidth={3} />
              </button>
            ) : (
              <button
                disabled
                className="inline-flex items-center justify-between gap-2 rounded-md border border-hairline bg-background/40 px-3 py-2 font-mono text-[11px] font-bold uppercase tracking-[0.18em] text-muted-foreground"
              >
                <span className="inline-flex items-center gap-2">
                  <Lock className="h-3 w-3" strokeWidth={2.5} />
                  encrypted
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Fog of war for locked */}
        {!isActive && (
          <div className="absolute inset-0 grid place-items-center overflow-hidden rounded-2xl">
            <div
              aria-hidden
              className="absolute inset-0 backdrop-blur-md"
              style={{
                background:
                  "linear-gradient(180deg, oklch(0.10 0.03 265 / 70%) 0%, oklch(0.08 0.03 265 / 92%) 100%)",
              }}
            />
            <div aria-hidden className="absolute inset-0 bg-grid opacity-30" />
            <div className="relative flex flex-col items-center gap-3 text-center">
              <div className="relative grid h-20 w-20 place-items-center rounded-2xl bg-background/80 ring-1 ring-hairline">
                <span
                  aria-hidden
                  className="absolute inset-[-2px] rounded-2xl opacity-60 blur-md"
                  style={{ background: "var(--glow-primary)" }}
                />
                <Lock className="relative h-9 w-9 text-foreground" strokeWidth={2} />
              </div>
              <div className="font-mono text-[11px] font-bold uppercase tracking-[0.3em] text-foreground">
                {lockedLabel}
              </div>
              <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                {unlockHint}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusPill({
  status,
  activeLabel,
  lockedPill,
}: {
  status: Status;
  activeLabel: string;
  lockedPill: string;
}) {
  if (status === "active") {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-md bg-accent px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-[0.22em] text-accent-foreground">
        <Terminal className="h-2.5 w-2.5" strokeWidth={3} />
        {activeLabel}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md border border-hairline bg-background/60 px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-[0.22em] text-muted-foreground">
      <Lock className="h-2.5 w-2.5" strokeWidth={3} />
      {lockedPill}
    </span>
  );
}

function MainframeBadge({ code, active }: { code: string; active: boolean }) {
  return (
    <div className="relative">
      {active && (
        <span
          aria-hidden
          className="absolute -inset-2 rounded-2xl opacity-70 blur-md animate-pulse-soft"
          style={{ background: "var(--glow-accent)" }}
        />
      )}
      <div
        className={cn(
          "relative grid h-24 w-24 place-items-center rounded-xl bg-background ring-1",
          active ? "ring-accent" : "ring-hairline"
        )}
      >
        {/* corner pins */}
        <span className={cn("absolute left-1 top-1 h-1 w-1 rounded-full", active ? "bg-accent" : "bg-hairline")} />
        <span className={cn("absolute right-1 top-1 h-1 w-1 rounded-full", active ? "bg-accent" : "bg-hairline")} />
        <span className={cn("absolute left-1 bottom-1 h-1 w-1 rounded-full", active ? "bg-accent" : "bg-hairline")} />
        <span className={cn("absolute right-1 bottom-1 h-1 w-1 rounded-full", active ? "bg-accent" : "bg-hairline")} />

        {/* rack slats */}
        <div className="flex flex-col items-stretch gap-1.5 px-3 py-2 w-full">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={cn(
                "h-1.5 rounded-sm",
                active && i < 3 ? "bg-accent/70" : "bg-hairline"
              )}
            />
          ))}
          <div className="mt-1 text-center font-mono text-[9px] font-bold tracking-[0.18em] text-muted-foreground">
            {code}
          </div>
        </div>
      </div>
    </div>
  );
}

function LedRack({ active }: { active: boolean }) {
  const slots = Array.from({ length: 6 });
  return (
    <div className="rounded-md border border-hairline bg-background/50 p-2">
      <div className="mb-1.5 flex items-center justify-between font-mono text-[8px] uppercase tracking-[0.22em] text-muted-foreground">
        <span>1U · slots</span>
        <span>{active ? "online" : "offline"}</span>
      </div>
      <div className="space-y-1">
        {slots.map((_, i) => (
          <div key={i} className="flex items-center gap-1.5">
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                active && i < 4
                  ? "bg-accent shadow-[0_0_6px_var(--accent)]"
                  : active && i === 4
                    ? "bg-primary/70"
                    : "bg-hairline"
              )}
            />
            <span className="h-px flex-1 bg-hairline" />
            <span className="font-mono text-[8px] tabular-nums text-muted-foreground">
              {String(i).padStart(2, "0")}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Vertical bus line between modules */
function BusConnector() {
  return (
    <div className="my-2 flex justify-center" aria-hidden>
      <div className="flex flex-col items-center gap-1">
        <span className="h-3 w-px bg-hairline" />
        <span className="h-1 w-1 rounded-full bg-accent/70" />
        <span className="h-6 w-px bg-gradient-to-b from-accent/70 to-primary/70" />
        <span className="h-1 w-1 rounded-full bg-primary/70" />
        <span className="h-3 w-px bg-hairline" />
      </div>
    </div>
  );
}
