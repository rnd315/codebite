import { BatteryFull, MessageCircleQuestion, Target, Trophy } from "lucide-react";

interface Props {
  uiLang: "EN" | "RO";
}

const t = {
  EN: {
    questTitle: "Daily quest",
    questSub: "Finish 1 lesson",
    questProgress: "0 / 1",
    leaderTitle: "Top debuggers · today",
    snippetTitle: "Debugger's Guild",
    snippetUser: "User_1337",
    snippet: "Syntax error in my while loop?",
    cta: ">_ Debug & Earn",
  },
  RO: {
    questTitle: "Misiunea zilei",
    questSub: "Termină 1 lecție",
    questProgress: "0 / 1",
    leaderTitle: "Top debuggeri · azi",
    snippetTitle: "Debugger's Guild",
    snippetUser: "User_1337",
    snippet: "Syntax error în bucla while?",
    cta: ">_ Debug & Câștigă",
  },
};

export function RightRail({ uiLang }: Props) {
  const c = t[uiLang];
  return (
    <aside className="space-y-4">
      <div className="rounded-2xl glass-strong p-5">
        <div className="flex items-center gap-2">
          <Target className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-bold text-foreground">{c.questTitle}</h3>
          <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            {c.questProgress}
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{c.questSub}</p>
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
            style={{ width: "12%" }}
          />
        </div>
      </div>

      <div className="rounded-2xl glass-strong p-5">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-accent" />
          <h3 className="text-sm font-bold text-foreground">{c.leaderTitle}</h3>
        </div>
        <ul className="mt-3 space-y-2.5">
          {[
            { name: "Maria", pts: 320, rank: "01" },
            { name: "Jin", pts: 285, rank: "02" },
            { name: "Sofia", pts: 210, rank: "03" },
          ].map((u) => (
            <li key={u.name} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-muted-foreground">{u.rank}</span>
                <span className="font-semibold text-foreground">{u.name}</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-primary">+{u.pts}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-2xl glass-strong p-5">
        <div className="flex items-center gap-2">
          <MessageCircleQuestion className="h-4 w-4 text-accent" />
          <h3 className="font-mono text-sm font-bold text-foreground">{c.snippetTitle}</h3>
        </div>
        <div className="mt-3 rounded-md border border-hairline bg-background/70 p-3 font-mono text-[11px]">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <span className="text-accent">$</span>
            <span className="text-foreground">{c.snippetUser}:</span>
          </div>
          <p className="mt-1 pl-3 text-foreground">{c.snippet}</p>
          <span className="mt-1 inline-block h-3 w-1.5 translate-y-0.5 animate-pulse-soft bg-accent align-middle" />
        </div>
        <button className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-md bg-accent px-4 py-2 font-mono text-xs font-bold uppercase tracking-[0.12em] text-accent-foreground transition-all hover:shadow-[0_0_30px_-6px_var(--glow-accent)]">
          {c.cta} <BatteryFull className="h-3 w-3" />
        </button>
      </div>
    </aside>
  );
}
