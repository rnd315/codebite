import { GraduationCap, Users } from "lucide-react";
import { cn } from "@/lib/utils";

export type View = "learn" | "community";

interface Props {
  value: View;
  onChange: (v: View) => void;
  uiLang: "EN" | "RO";
}

export function ViewSwitcher({ value, onChange, uiLang }: Props) {
  const labels =
    uiLang === "EN"
      ? { learn: "Learning", community: "Community" }
      : { learn: "Învățare", community: "Comunitate" };

  const items: { id: View; label: string; icon: React.ElementType }[] = [
    { id: "learn", label: labels.learn, icon: GraduationCap },
    { id: "community", label: labels.community, icon: Users },
  ];

  return (
    <div className="relative inline-flex items-center rounded-full glass p-1">
      <span
        className="absolute inset-y-1 w-1/2 rounded-full bg-gradient-to-r from-primary/90 to-accent/90 shadow-[0_0_30px_-4px_var(--glow-primary)] transition-transform duration-300"
        style={{ transform: value === "learn" ? "translateX(0)" : "translateX(100%)" }}
        aria-hidden
      />
      {items.map((it) => {
        const active = value === it.id;
        return (
          <button
            key={it.id}
            onClick={() => onChange(it.id)}
            className={cn(
              "relative z-10 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors",
              active ? "text-background" : "text-muted-foreground hover:text-foreground"
            )}
          >
            <it.icon className="h-4 w-4" strokeWidth={2.25} />
            {it.label}
          </button>
        );
      })}
    </div>
  );
}
