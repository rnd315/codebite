import { ArrowRight, Cpu, Sparkles, Zap } from "lucide-react";

interface HeroProps {
  uiLang: "EN" | "RO";
  view: "learn" | "community";
}

const t = {
  EN: {
    learn: {
      tag: "session://resume",
      title: "> compile your skills,",
      titleAccent: "byte by byte.",
      sub: "You're 3 of 8 commits into Loops & While. Re-attach to the running process.",
      cta: ">_ resume_lesson",
      a: "1.24K XP / wk",
      b: "12d uptime",
      c: "neural-tutor v2",
    },
    community: {
      tag: "guild://218 online",
      title: "> debug peers,",
      titleAccent: "recharge battery.",
      sub: "Patch real bugs from your stack. Top debuggers rotate every hour.",
      cta: ">_ open_threads",
      a: "12 open tickets",
      b: "+218 debuggers",
      c: "rep multiplier 1.5×",
    },
  },
  RO: {
    learn: {
      tag: "session://resume",
      title: "> compilează-ți skill-urile,",
      titleAccent: "byte cu byte.",
      sub: "Ești la commit 3 din 8 din Bucle & While. Re-atașează la proces.",
      cta: ">_ resume_lesson",
      a: "1.24K XP / săpt",
      b: "12d uptime",
      c: "tutor-neural v2",
    },
    community: {
      tag: "guild://218 online",
      title: "> debug colegii,",
      titleAccent: "reîncarcă bateria.",
      sub: "Patch la bug-uri reale din stack-ul tău. Top debuggerii se rotesc orar.",
      cta: ">_ open_threads",
      a: "12 tickete deschise",
      b: "+218 debuggeri",
      c: "multiplicator 1.5×",
    },
  },
};

export function Hero({ uiLang, view }: HeroProps) {
  const c = t[uiLang][view];
  return (
    <section className="relative overflow-hidden rounded-3xl glass-strong p-6 sm:p-8">
      <div
        aria-hidden
        className="pointer-events-none absolute -inset-px rounded-3xl opacity-60 animate-shimmer"
        style={{
          background:
            "conic-gradient(from 120deg at 50% 50%, transparent 0deg, var(--glow-primary) 90deg, transparent 180deg, var(--glow-accent) 270deg, transparent 360deg)",
          maskImage:
            "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
          WebkitMaskComposite: "xor",
          maskComposite: "exclude",
          padding: 1,
        }}
      />
      <div
        aria-hidden
        className="absolute -right-20 -top-24 h-72 w-72 rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(closest-side, var(--glow-accent), transparent)" }}
      />

      <div className="relative grid gap-6 sm:grid-cols-[1fr_auto] sm:items-end">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-primary" />
            {c.tag}
          </div>
          <h1 className="mt-4 font-mono text-3xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-5xl">
            {c.title}
            <br />
            <span className="text-accent">{c.titleAccent}</span>
          </h1>
          <p className="mt-3 max-w-xl text-sm text-muted-foreground sm:text-base">{c.sub}</p>

          <div className="mt-5 flex flex-wrap items-center gap-2 font-mono text-[11px]">
            <Chip icon={<Zap className="h-3 w-3" />}>{c.a}</Chip>
            <Chip icon={<Sparkles className="h-3 w-3" />}>{c.b}</Chip>
            <Chip icon={<Cpu className="h-3 w-3" />}>{c.c}</Chip>
          </div>
        </div>

        <button className="group inline-flex items-center gap-2 self-start rounded-md bg-accent px-5 py-3 font-mono text-sm font-bold uppercase tracking-[0.12em] text-accent-foreground transition-all hover:gap-3 hover:shadow-[0_0_40px_-4px_var(--glow-accent)]">
          {c.cta}
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" strokeWidth={3} />
        </button>
      </div>
    </section>
  );
}

function Chip({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full glass px-2.5 py-1 uppercase tracking-[0.18em] text-muted-foreground">
      <span className="text-primary">{icon}</span>
      {children}
    </span>
  );
}
