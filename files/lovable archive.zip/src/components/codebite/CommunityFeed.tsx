import { ArrowUpRight, BatteryFull, MessageSquare, Sparkles } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface Props {
  uiLang: "EN" | "RO";
  lang: "cpp" | "py";
}

type Filter = "all" | "open" | "mine";

const t = {
  EN: {
    title: "Debugger's Guild",
    sub: "Help a peer, earn a 💠 Token!",
    filters: { all: "All", open: "Unanswered", mine: "My stack" },
    cta: ">_ Debug & Earn",
    ago: (m: number) => `${m}m ago`,
    asked: "pushed",
    items: [
      {
        user: "User_1337",
        tag: "loops",
        lang: "cpp" as const,
        time: 2,
        title: "Syntax error in my while loop?",
        body: "Checking i < 10 inside the loop but never incrementing i. Compiler stays silent — what's the safe pattern?",
        replies: 0,
        hearts: 4,
      },
      {
        user: "Mira_dev",
        tag: "lists",
        lang: "py" as const,
        time: 6,
        title: "List comprehension vs for-loop perf",
        body: "Measurable diff at n=10⁶ when filtering primes? Both compile to similar bytecode…",
        replies: 3,
        hearts: 12,
      },
      {
        user: "Theo.cpp",
        tag: "sorting",
        lang: "cpp" as const,
        time: 14,
        title: "Bubble sort beats std::sort on n<16?",
        body: "Under 16 elements my bubble impl wins. Real result or measurement bias?",
        replies: 1,
        hearts: 7,
      },
      {
        user: "Yusra_py",
        tag: "recursion",
        lang: "py" as const,
        time: 28,
        title: "RecursionError on Fibonacci(35)",
        body: "Naive recursion blows the stack. Memoization fixes it — how do I explain WHY to a beginner?",
        replies: 5,
        hearts: 18,
      },
    ],
  },
  RO: {
    title: "Debugger's Guild",
    sub: "Ajută un coleg, câștigă un 💠 Token!",
    filters: { all: "Toate", open: "Fără răspuns", mine: "Stack-ul meu" },
    cta: ">_ Debug & Câștigă",
    ago: (m: number) => `acum ${m}m`,
    asked: "push",
    items: [
      {
        user: "User_1337",
        tag: "bucle",
        lang: "cpp" as const,
        time: 2,
        title: "Syntax error în bucla while?",
        body: "Verific i < 10 dar nu incrementez i. Compilatorul tace — care e pattern-ul corect?",
        replies: 0,
        hearts: 4,
      },
      {
        user: "Mira_dev",
        tag: "liste",
        lang: "py" as const,
        time: 6,
        title: "List comprehension vs for-loop perf",
        body: "Diferență reală la n=10⁶ când filtrez prime? Ambele compilează la bytecode similar…",
        replies: 3,
        hearts: 12,
      },
      {
        user: "Theo.cpp",
        tag: "sortare",
        lang: "cpp" as const,
        time: 14,
        title: "Bubble sort bate std::sort la n<16?",
        body: "Sub 16 elemente implementarea mea bubble câștigă. Real sau bias de măsurare?",
        replies: 1,
        hearts: 7,
      },
      {
        user: "Yusra_py",
        tag: "recursie",
        lang: "py" as const,
        time: 28,
        title: "RecursionError la Fibonacci(35)",
        body: "Recursia naivă explodează stack-ul. Memoizarea rezolvă — cum explic DE CE unui începător?",
        replies: 5,
        hearts: 18,
      },
    ],
  },
};

export function CommunityFeed({ uiLang, lang }: Props) {
  const c = t[uiLang];
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = c.items.filter((q) => {
    if (filter === "open") return q.replies === 0;
    if (filter === "mine") return q.lang === lang;
    return true;
  });

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-accent">
            ~/guild --live
          </div>
          <h2 className="mt-1 font-mono text-lg font-bold text-foreground">{c.title}</h2>
          <p className="text-sm text-muted-foreground">{c.sub}</p>
        </div>

        <div className="flex items-center gap-1 rounded-md border border-hairline bg-background/60 p-1 font-mono">
          {(Object.keys(c.filters) as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-sm px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.15em] transition-colors",
                filter === f
                  ? "bg-foreground text-background"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {c.filters[f]}
            </button>
          ))}
        </div>
      </div>

      <ul className="grid gap-3 sm:grid-cols-2">
        {filtered.map((q) => (
          <li
            key={q.title}
            className="group relative overflow-hidden rounded-xl border border-hairline bg-background/60 transition-all hover:border-accent/50 hover:shadow-[0_0_30px_-10px_var(--glow-accent)]"
          >
            {/* Terminal title bar */}
            <div className="flex items-center justify-between gap-2 border-b border-hairline bg-secondary/40 px-3 py-1.5">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-destructive/70" />
                <span className="h-2 w-2 rounded-full bg-streak/70" />
                <span className="h-2 w-2 rounded-full bg-accent/70" />
                <span className="ml-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  ~/threads/{q.tag}.{q.lang}
                </span>
              </div>
              <span
                className={cn(
                  "font-mono text-[9px] uppercase tracking-[0.2em]",
                  q.lang === "cpp" ? "text-primary" : "text-accent"
                )}
              >
                {q.lang === "cpp" ? "C++" : "PY"}
              </span>
            </div>

            {/* Terminal body */}
            <div className="p-4 font-mono text-xs">
              <div className="flex items-center gap-2 text-muted-foreground">
                <span className="text-accent">$</span>
                <span className="text-foreground">{q.user}</span>
                <span className="text-muted-foreground">·</span>
                <span>{c.ago(q.time)}</span>
              </div>
              <div className="mt-2 flex gap-2">
                <span className="text-accent">{">"}</span>
                <span className="font-bold text-foreground">{q.title}</span>
              </div>
              <p className="mt-1.5 pl-4 text-[11px] leading-relaxed text-muted-foreground line-clamp-2">
                {q.body}
              </p>

              <div className="mt-4 flex items-center justify-between border-t border-hairline pt-3">
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <MessageSquare className="h-3 w-3" /> {q.replies}
                  </span>
                  <span className="inline-flex items-center gap-1 text-primary">
                    <BatteryFull className="h-3 w-3" /> +{q.hearts}
                  </span>
                  {q.replies === 0 && (
                    <span className="inline-flex items-center gap-1 rounded-sm bg-accent/15 px-1.5 py-0.5 text-accent">
                      <Sparkles className="h-3 w-3" /> 1.5×
                    </span>
                  )}
                </div>
                <button className="inline-flex items-center gap-1 rounded-md bg-accent px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.1em] text-accent-foreground transition-all hover:shadow-[0_0_20px_-4px_var(--glow-accent)]">
                  {c.cta}
                  <ArrowUpRight className="h-3 w-3" strokeWidth={3} />
                </button>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
