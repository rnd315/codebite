# Backs up the entire CodeByte project (including the SQLite DB) to a dated zip archive.
# Excludes: node_modules, .venv, __pycache__, *.pyc, and any previous backup zips.
# Usage: .\scripts\backup.ps1 [-OutputDir <path>]
#   OutputDir defaults to the project root.

param(
    [string]$OutputDir = ""
)

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ProjectName = "Codebyte"
$Date        = Get-Date -Format "yyyy-MM-dd"

if (-not $OutputDir) { $OutputDir = $ProjectRoot }
$Archive = Join-Path $OutputDir "${ProjectName}-${Date}.zip"

Write-Host "Backing up $ProjectRoot -> $Archive"

$ExcludedSegments = @("node_modules", ".venv", "__pycache__")

$Files = Get-ChildItem -Path $ProjectRoot -Recurse -File | Where-Object {
    $parts = $_.FullName.Substring($ProjectRoot.Length + 1) -split "\\"

    $skip = $false
    foreach ($seg in $ExcludedSegments) {
        if ($parts -contains $seg) { $skip = $true; break }
    }
    if ($_.Extension -in @(".pyc", ".pyo"))        { $skip = $true }
    if ($_.Name -like "${ProjectName}-*.zip")       { $skip = $true }

    -not $skip
}

# Stage filtered files in a temp folder, preserving relative paths
$TempDir = Join-Path $env:TEMP "codebite_backup_$Date"
if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force }
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

foreach ($file in $Files) {
    $relative  = $file.FullName.Substring($ProjectRoot.Length + 1)
    $destPath  = Join-Path $TempDir $relative
    $destParent = Split-Path $destPath -Parent
    if (-not (Test-Path $destParent)) {
        New-Item -ItemType Directory -Path $destParent -Force | Out-Null
    }
    Copy-Item -Path $file.FullName -Destination $destPath
}

# Remove today's archive if it already exists
if (Test-Path $Archive) { Remove-Item $Archive -Force }

Compress-Archive -Path "$TempDir\*" -DestinationPath $Archive

# Cleanup temp folder
Remove-Item $TempDir -Recurse -Force

$sizeMB = [math]::Round((Get-Item $Archive).Length / 1MB, 2)
Write-Host "Done. Archive: $Archive ($sizeMB MB)"
