import Navbar from './Navbar'
import MobileNav from './MobileNav'

function BackgroundFX() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-70" />
      <div
        className="absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full opacity-60 blur-3xl"
        style={{ background: 'radial-gradient(closest-side, var(--glow-primary), transparent)' }}
      />
      <div
        className="absolute bottom-[-200px] right-[-160px] h-[480px] w-[640px] rounded-full opacity-50 blur-3xl"
        style={{ background: 'radial-gradient(closest-side, var(--glow-accent), transparent)' }}
      />
      <div
        className="absolute inset-0 opacity-[0.5]"
        style={{ background: 'radial-gradient(ellipse at top, transparent 0%, var(--background) 75%)' }}
      />
    </div>
  )
}

export default function Layout({ children }) {
  return (
    <div className="relative min-h-screen text-foreground">
      <BackgroundFX />
      <Navbar />
      <main className="relative z-10 pt-14 pb-16 sm:pb-4 mx-auto max-w-7xl px-4 lg:px-8">
        {children}
      </main>
      <MobileNav />
    </div>
  )
}
