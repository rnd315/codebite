import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'

export default function StreakCounter() {
  const { t } = useTranslation()
  const streak = useStore((s) => s.streak)

  return (
    <span
      className="font-mono text-sm font-bold text-amber-500 dark:text-amber-400"
      title={`${streak} ${t('gamification.streak')}`}
    >
      ⚡ {streak}
    </span>
  )
}
