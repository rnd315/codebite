export const MAX_LIVES = 5
export const MAX_TOKENS = 5   // display alias — backend field is still `lives`
export const XP_PER_LESSON = 10
export const XP_PER_QUIZ = 5
export const XP_PER_ACCEPTED = 15
export const DEBUG = false

export const MODULES = [
  {
    id: 'mod_01',
    slug: 'foundations',
    label: 'MOD_01 // FOUNDATIONS',
    subtitle: 'Variables · I/O · Branches',
    categories: ['basics'],
  },
  {
    id: 'mod_02',
    slug: 'loops-logic',
    label: 'MOD_02 // LOOPS & LOGIC',
    subtitle: 'While · For · Arrays',
    categories: ['arrays & strings'],
  },
  {
    id: 'mod_03',
    slug: 'algorithms',
    label: 'MOD_03 // ALGORITHMS',
    subtitle: 'Sorting · Searching',
    categories: ['sorting', 'searching'],
  },
]
