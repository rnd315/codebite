import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ChevronDown, ChevronUp, Terminal } from 'lucide-react'
import client from '../../api/client'
import useStore from '../../store/useStore'
import AnswerCard from './AnswerCard'
import AnswerForm from './AnswerForm'

export default function QuestionCard({ question, onAnswerAccepted }) {
  const { t } = useTranslation()
  const user = useStore((s) => s.user)
  const [expanded, setExpanded] = useState(false)
  const [answers, setAnswers] = useState(null)
  const [loading, setLoading] = useState(false)

  const toggle = async () => {
    if (!expanded && answers === null) {
      setLoading(true)
      try {
        const { data } = await client.get(`/community/questions/${question.id}/answers`)
        setAnswers(data)
      } finally {
        setLoading(false)
      }
    }
    setExpanded((p) => !p)
  }

  const handlePostAnswer = async (body) => {
    const { data } = await client.post(`/community/answers/${question.id}`, { body })
    setAnswers((prev) => [...(prev ?? []), data])
  }

  const handleAccept = async (answerId) => {
    const { data } = await client.patch(`/community/answers/${answerId}/accept`)
    setAnswers((prev) => prev.map((a) => (a.id === answerId ? data : a)))
    onAnswerAccepted?.()
  }

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-dark-border bg-white dark:bg-dark-card">
      <button
        onClick={toggle}
        className="w-full text-left p-4 flex items-start gap-3 hover:bg-slate-50 dark:hover:bg-dark-border/30 transition-colors"
      >
        <Terminal size={14} className="flex-shrink-0 mt-1 text-neon-cyan dark:text-neon-cyan text-deep-cyan" />
        <div className="flex-1 min-w-0">
          {/* Terminal-style username */}
          <p className="font-mono text-[10px] text-slate-400 dark:text-slate-600 mb-1 uppercase tracking-wide">
            // {question.author_username}
          </p>
          <p className="text-sm text-slate-800 dark:text-slate-200">{question.body}</p>
          <p className="font-mono text-xs text-slate-400 dark:text-slate-600 mt-1.5">
            {question.answer_count} {t('community.answers')}
          </p>
        </div>
        {expanded
          ? <ChevronUp size={15} className="flex-shrink-0 text-slate-400" />
          : <ChevronDown size={15} className="flex-shrink-0 text-slate-400" />
        }
      </button>

      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-slate-100 dark:border-dark-border pt-3">
          {loading && (
            <p className="font-mono text-xs text-slate-500 dark:text-slate-600">{t('common.loading')}</p>
          )}
          {answers !== null && answers.length === 0 && (
            <p className="font-mono text-xs text-slate-400 dark:text-slate-600">// No fixes yet — be the first.</p>
          )}
          {answers?.map((a) => (
            <AnswerCard
              key={a.id}
              answer={a}
              questionAuthorId={question.user_id}
              onAccept={handleAccept}
            />
          ))}
          <AnswerForm onSubmit={handlePostAnswer} submitLabel=">_ Debug & Earn" />
        </div>
      )}
    </div>
  )
}
