import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Plus, X, Terminal } from 'lucide-react'
import client from '../api/client'
import useStore from '../store/useStore'
import QuestionCard from '../components/community/QuestionCard'
import Button from '../components/ui/Button'

export default function Community() {
  const { t } = useTranslation()
  const { setLives } = useStore()
  const [questions, setQuestions] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [newQuestion, setNewQuestion] = useState({ lesson_id: '', body: '' })
  const [lessons, setLessons] = useState([])
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [{ data: q }, { data: l }] = await Promise.all([
          client.get('/community/questions'),
          client.get('/lessons'),
        ])
        setQuestions(q)
        setLessons(l)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const handleAskQuestion = async (e) => {
    e.preventDefault()
    if (!newQuestion.body.trim() || !newQuestion.lesson_id) return
    setSubmitting(true)
    try {
      const { data } = await client.post('/community/questions', {
        lesson_id: parseInt(newQuestion.lesson_id),
        body: newQuestion.body.trim(),
      })
      setQuestions((p) => [data, ...p])
      setNewQuestion({ lesson_id: '', body: '' })
      setShowForm(false)
    } finally {
      setSubmitting(false)
    }
  }

  const handleAnswerAccepted = async () => {
    try {
      const { data: me } = await client.get('/auth/me')
      setLives(me.lives)
    } catch {}
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 font-mono text-sm text-slate-500">
        {t('common.loading')}
      </div>
    )
  }

  return (
    <div className="py-6 max-w-2xl mx-auto space-y-4">
      {/* Guild header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Terminal size={16} className="text-neon-cyan dark:text-neon-cyan text-deep-cyan" />
            <h1 className="font-mono text-xl font-bold text-slate-900 dark:text-white">
              {t('community.guildTitle')}
            </h1>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-mono">
            {t('community.guildSubtitle')}
          </p>
        </div>
        <Button
          onClick={() => setShowForm((p) => !p)}
          size="sm"
          variant={showForm ? 'ghost' : 'primary'}
        >
          {showForm
            ? <><X size={14} /> cancel</>
            : <><Plus size={14} /> post issue</>
          }
        </Button>
      </div>

      {/* Ask question form */}
      {showForm && (
        <form
          onSubmit={handleAskQuestion}
          className="bg-white dark:bg-dark-card border border-slate-200 dark:border-dark-border rounded-xl p-4 space-y-3"
        >
          <p className="font-mono text-xs text-slate-400 dark:text-slate-500">
            &gt;_ new issue
          </p>
          <select
            value={newQuestion.lesson_id}
            onChange={(e) => setNewQuestion((p) => ({ ...p, lesson_id: e.target.value }))}
            required
            className="w-full bg-slate-100 dark:bg-dark-bg border border-slate-200 dark:border-dark-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-neon-cyan text-slate-800 dark:text-white font-mono"
          >
            <option value="">// select module...</option>
            {lessons.map((l) => (
              <option key={l.id} value={l.id}>{l.title_en}</option>
            ))}
          </select>
          <textarea
            value={newQuestion.body}
            onChange={(e) => setNewQuestion((p) => ({ ...p, body: e.target.value }))}
            placeholder="// Describe your bug or question..."
            rows={3}
            required
            className="w-full bg-slate-100 dark:bg-dark-bg border border-slate-200 dark:border-dark-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-neon-cyan resize-none font-mono text-slate-800 dark:text-gray-200 placeholder-slate-400 dark:placeholder-slate-600"
          />
          <Button type="submit" disabled={submitting || !newQuestion.body.trim() || !newQuestion.lesson_id}>
            {submitting ? '...' : '>_ Submit Issue'}
          </Button>
        </form>
      )}

      {/* Questions list */}
      {questions.length === 0 ? (
        <p className="text-center font-mono text-sm text-slate-500 dark:text-slate-600 py-10">
          // No issues yet. Be the first to post.
        </p>
      ) : (
        <div className="space-y-3">
          {questions.map((q) => (
            <QuestionCard key={q.id} question={q} onAnswerAccepted={handleAnswerAccepted} />
          ))}
        </div>
      )}
    </div>
  )
}
