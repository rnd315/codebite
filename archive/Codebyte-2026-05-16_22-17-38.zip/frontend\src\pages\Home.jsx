import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import useAuth from '../hooks/useAuth'
import Button from '../components/ui/Button'

export default function Home() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const { login, register, loading, error } = useAuth()
  const [tab, setTab] = useState('login') // 'login' | 'register'
  const [form, setForm] = useState({ username: '', email: '', password: '' })

  const handleSubmit = async (e) => {
    e.preventDefault()
    const result =
      tab === 'login'
        ? await login({ email: form.email, password: form.password })
        : await register(form)
    if (result.ok) navigate(tab === 'login' ? '/pathway' : '/onboarding')
  }

  const update = (field) => (e) => setForm((p) => ({ ...p, [field]: e.target.value }))

  return (
    <div className="min-h-screen bg-dark-bg flex flex-col items-center justify-center px-4 py-12">
      {/* Hero */}
      <div className="text-center mb-10 max-w-xl">
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight mb-3">
          <span className="text-neon-cyan">Code</span>
          <span className="text-white">Bite</span>
        </h1>
        <p className="text-xl text-gray-300 mb-2">{t('auth.tagline')}</p>
        <p className="text-sm text-gray-500">{t('auth.subtitle')}</p>

        <div className="flex items-center justify-center gap-6 mt-6 text-sm text-gray-400">
          <span className="flex items-center gap-1.5">❤️ Lives system</span>
          <span className="flex items-center gap-1.5">🔥 Streaks</span>
          <span className="flex items-center gap-1.5">⚡ Visualizer</span>
        </div>
      </div>

      {/* Auth card */}
      <div className="w-full max-w-sm bg-dark-card border border-dark-border rounded-2xl p-6 shadow-2xl">
        {/* Tab switcher */}
        <div className="flex rounded-xl overflow-hidden border border-dark-border mb-5">
          {['login', 'register'].map((t_) => (
            <button
              key={t_}
              onClick={() => setTab(t_)}
              className={`flex-1 py-2.5 text-sm font-medium transition-colors
                ${tab === t_
                  ? 'bg-neon-cyan text-dark-bg'
                  : 'text-gray-400 hover:text-white'
                }`}
            >
              {t_ === 'login' ? t('auth.login') : t('auth.register')}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {tab === 'register' && (
            <input
              type="text"
              placeholder={t('auth.username')}
              value={form.username}
              onChange={update('username')}
              required
              className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-neon-cyan text-white placeholder-gray-500"
            />
          )}
          <input
            type="email"
            placeholder={t('auth.email')}
            value={form.email}
            onChange={update('email')}
            required
            className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-neon-cyan text-white placeholder-gray-500"
          />
          <input
            type="password"
            placeholder={t('auth.password')}
            value={form.password}
            onChange={update('password')}
            required
            className="w-full bg-dark-bg border border-dark-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-neon-cyan text-white placeholder-gray-500"
          />

          {error && (
            <p className="text-xs text-red-400 text-center">
              {error.startsWith('error') ? t(`auth.${error}`) : error}
            </p>
          )}

          <Button type="submit" disabled={loading} className="w-full mt-1">
            {loading
              ? tab === 'login' ? t('auth.loggingIn') : t('auth.registering')
              : tab === 'login' ? t('auth.loginBtn') : t('auth.registerBtn')
            }
          </Button>
        </form>

        <button
          onClick={() => setTab(tab === 'login' ? 'register' : 'login')}
          className="mt-4 w-full text-xs text-gray-500 hover:text-gray-300 transition-colors text-center"
        >
          {tab === 'login' ? t('auth.switchToRegister') : t('auth.switchToLogin')}
        </button>
      </div>
    </div>
  )
}
