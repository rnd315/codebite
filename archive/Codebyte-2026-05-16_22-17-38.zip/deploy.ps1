# =============================================================================
# CodeBite — Deploy Script  (dev → prod)
# =============================================================================
# Mirrors local dev to codebite.crystalmind.ro over SSH + rsync.
# Usage: .\deploy.ps1
#
# FIRST-TIME SETUP:
#   1. Copy .env to the server manually:
#      scp .env claude-agent@codebite.crystalmind.ro:/var/www/codebite.crystalmind.ro/backend/.env
#   2. On the server, create the venv and install deps once:
#      cd /var/www/codebite.crystalmind.ro/backend
#      python3 -m venv .venv
#      .venv/bin/pip install -r requirements.txt
#   3. Set up the systemd service (see README or ask for a template).
#   4. Ensure SSH key auth is configured (no password prompts).
# =============================================================================

$REMOTE_USER     = "claude-agent"
$REMOTE_HOST     = "codebite.crystalmind.ro"
$REMOTE_PATH     = "/var/www/codebite.crystalmind.ro"
$BACKEND_SERVICE = "codebite"
$SSH_KEY         = "$env:USERPROFILE\.ssh\id_rsa"   # set to "" to use SSH default

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

function Write-Step($msg) { Write-Host "`n[>>] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[OK] $msg"  -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[!!] $msg"  -ForegroundColor Yellow }
function Write-Fail($msg) { Write-Host "[XX] $msg"  -ForegroundColor Red; exit 1 }

# Build SSH -i flag if key path is set and the file exists
function Get-SSHKeyFlag {
    if ($SSH_KEY -and (Test-Path $SSH_KEY)) {
        return "-i `"$SSH_KEY`""
    }
    return ""
}

# Resolve correct rsync + ssh commands (WSL or native)
function Resolve-Rsync {
    # Prefer WSL rsync (most reliable on Windows for SSH-based sync)
    $wslCheck = & wsl rsync --version 2>$null
    if ($LASTEXITCODE -eq 0) {
        return "wsl"
    }
    # Fall back to native rsync in PATH (Scoop / Choco)
    $nativeCheck = & rsync --version 2>$null
    if ($LASTEXITCODE -eq 0) {
        return "native"
    }
    return $null
}

# Convert a Windows absolute path to a WSL-compatible path (e.g. C:\foo → /mnt/c/foo)
function ConvertTo-WslPath($winPath) {
    $result = & wsl wslpath ($winPath -replace '\\', '/')
    return $result.Trim()
}

# Run rsync (handles WSL vs native transparently)
function Invoke-Rsync($rsyncMode, $src, $dst, [string[]]$excludes) {
    $keyFlag = Get-SSHKeyFlag
    $sshOpt  = if ($keyFlag) { "-e `"ssh $keyFlag`"" } else { "" }

    $excludeArgs = $excludes | ForEach-Object { "--exclude=$_" }

    if ($rsyncMode -eq "wsl") {
        # Convert local source path to WSL path
        $wslSrc = ConvertTo-WslPath $src
        # Build wsl rsync argument list (no PowerShell expansion issues)
        $rsyncArgs = @("-avz", "--delete") + $excludeArgs
        if ($sshOpt) { $rsyncArgs += $sshOpt }
        $rsyncArgs += @($wslSrc, "${REMOTE_USER}@${REMOTE_HOST}:${dst}")
        & wsl rsync @rsyncArgs
    } else {
        $rsyncArgs = @("-avz", "--delete") + $excludeArgs
        if ($sshOpt) { $rsyncArgs += $sshOpt }
        $rsyncArgs += @($src, "${REMOTE_USER}@${REMOTE_HOST}:${dst}")
        & rsync @rsyncArgs
    }
}

# Run an SSH command (handles WSL vs native)
function Invoke-SSH($rsyncMode, $cmd) {
    $keyFlag = Get-SSHKeyFlag
    if ($rsyncMode -eq "wsl") {
        if ($keyFlag) {
            & wsl ssh $keyFlag "${REMOTE_USER}@${REMOTE_HOST}" $cmd
        } else {
            & wsl ssh "${REMOTE_USER}@${REMOTE_HOST}" $cmd
        }
    } else {
        if ($keyFlag) {
            & ssh $keyFlag "${REMOTE_USER}@${REMOTE_HOST}" $cmd
        } else {
            & ssh "${REMOTE_USER}@${REMOTE_HOST}" $cmd
        }
    }
}

# ---------------------------------------------------------------------------
# STEP 1 — Detect rsync
# ---------------------------------------------------------------------------
Write-Step "Checking for rsync..."

$rsyncMode = Resolve-Rsync

if (-not $rsyncMode) {
    Write-Fail @"
rsync not found. Install it with one of the following:

  Scoop  :  scoop install rsync
  Choco  :  choco install rsync
  WSL    :  wsl --install
             (then inside WSL: sudo apt install rsync)

After installing, re-run this script.
"@
}

Write-Ok "rsync available ($rsyncMode mode)"

# ---------------------------------------------------------------------------
# STEP 2 — SSH connectivity check
# ---------------------------------------------------------------------------
Write-Step "Testing SSH connection to $REMOTE_HOST..."

$pingResult = Invoke-SSH $rsyncMode "echo __ok__" 2>&1
if ($pingResult -notmatch "__ok__") {
    Write-Fail @"
Cannot reach $REMOTE_USER@$REMOTE_HOST via SSH.

Make sure your SSH key is set up:
  ssh-keygen -t ed25519 -C "deploy"
  ssh-copy-id $REMOTE_USER@$REMOTE_HOST

Or copy the key manually into ~/.ssh/authorized_keys on the server.
"@
}

Write-Ok "SSH connection successful"

# ---------------------------------------------------------------------------
# STEP 3 — Build frontend
# ---------------------------------------------------------------------------
Write-Step "Building frontend..."

$projectRoot = $PSScriptRoot
Set-Location "$projectRoot\frontend"

& node .\node_modules\vite\bin\vite.js build
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Frontend build failed. Fix the errors above and re-run."
}

Set-Location $projectRoot
Write-Ok "Frontend built → frontend\dist\"

# ---------------------------------------------------------------------------
# STEP 4 — Sync frontend dist → Nginx web root
# ---------------------------------------------------------------------------
Write-Step "Syncing frontend to server..."

$frontendSrc = "$projectRoot\frontend\dist\"
Invoke-Rsync $rsyncMode $frontendSrc "$REMOTE_PATH/" @()

if ($LASTEXITCODE -ne 0) { Write-Fail "Frontend rsync failed." }
Write-Ok "Frontend synced → $REMOTE_PATH/"

# ---------------------------------------------------------------------------
# STEP 5 — Sync backend (excluding sensitive + generated files)
# ---------------------------------------------------------------------------
Write-Step "Syncing backend to server..."

$backendSrc = "$projectRoot\backend\"
$backendExcludes = @(
    ".env",
    "codebite.db",
    ".venv/",
    "__pycache__/",
    "*.pyc",
    "*.pyo",
    ".pytest_cache/"
)
Invoke-Rsync $rsyncMode $backendSrc "$REMOTE_PATH/backend/" $backendExcludes

if ($LASTEXITCODE -ne 0) { Write-Fail "Backend rsync failed." }
Write-Ok "Backend synced → $REMOTE_PATH/backend/"

# ---------------------------------------------------------------------------
# STEP 6 — Remote: install deps + migrate + restart service
# ---------------------------------------------------------------------------
Write-Step "Running remote post-deploy steps..."

$remoteCmd = @"
set -e
cd $REMOTE_PATH/backend
echo '-- pip install'
.venv/bin/pip install -r requirements.txt -q
echo '-- alembic migrate'
.venv/bin/alembic upgrade head
echo '-- restart service'
sudo systemctl restart $BACKEND_SERVICE
sleep 1
if sudo systemctl is-active --quiet $BACKEND_SERVICE; then
  echo 'SERVICE_OK'
else
  echo 'SERVICE_FAILED'
  sudo journalctl -u $BACKEND_SERVICE -n 20 --no-pager
fi
"@

$remoteOutput = Invoke-SSH $rsyncMode $remoteCmd
Write-Host $remoteOutput

if ($remoteOutput -match "SERVICE_FAILED") {
    Write-Warn "Backend service failed to start. Check logs above."
} elseif ($remoteOutput -match "SERVICE_OK") {
    Write-Ok "Backend service is running"
} else {
    Write-Warn "Could not confirm service status — check manually: ssh $REMOTE_USER@$REMOTE_HOST"
}

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
Write-Host ""
Write-Ok "Deploy complete → https://$REMOTE_HOST"
Write-Host ""
