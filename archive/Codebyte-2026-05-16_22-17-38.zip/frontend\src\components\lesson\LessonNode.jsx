import { useNavigate } from 'react-router-dom'
import { Lock, Play } from 'lucide-react'

export default function LessonNode({ lesson, status, lang }) {
  const navigate = useNavigate()

  const isLocked = status === 'locked'
  const isCompleted = status === 'completed'
  const isAvailable = status === 'available'

  const title = lang === 'ro' ? lesson.title_ro : lesson.title_en
  const category = lesson.category?.toUpperCase().replace(/ & /g, ' · ') ?? ''

  const handleClick = () => {
    if (!isLocked) navigate(`/lesson/${lesson.slug}`)
  }

  return (
    <div
      onClick={handleClick}
      className={`flex flex-col items-center text-center gap-2 select-none ${
        !isLocked ? 'cursor-pointer group' : 'cursor-not-allowed opacity-40'
      }`}
    >
      {/* TAP TO START label — only for active node */}
      {isAvailable && (
        <span className="text-[9px] font-mono text-gray-500 uppercase tracking-[0.22em] border border-dark-border rounded-full px-3 py-1 bg-dark-bg/50">
          Tap to start
        </span>
      )}

      {/* Node circle */}
      {isCompleted && (
        <div className="w-14 h-14 rounded-full flex items-center justify-center text-neon-cyan text-2xl font-bold bg-[#061a1a] border-2 border-[#0a4040] group-hover:scale-105 group-hover:border-neon-cyan/60 transition-all duration-200">
          ✓
        </div>
      )}

      {isAvailable && (
        <div className="w-16 h-16 rounded-full border-2 border-neon-cyan bg-neon-cyan/10 flex items-center justify-center node-pulse group-hover:scale-105 transition-transform duration-200">
          <Play size={22} className="text-white ml-1" fill="white" />
        </div>
      )}

      {isLocked && (
        <div className="w-12 h-12 rounded-full border border-dark-border bg-dark-card flex items-center justify-center text-gray-600">
          <Lock size={15} />
        </div>
      )}

      {/* Labels below circle */}
      <div className="space-y-0.5">
        <p className={`text-sm font-bold leading-tight ${isLocked ? 'text-gray-600' : 'text-white'}`}>
          {title}
        </p>
        <p className="text-[9px] font-mono text-gray-600 uppercase tracking-wider">
          {category}
        </p>
        {isCompleted && (
          <p className="text-yellow-400 text-xs tracking-widest mt-1">★★★</p>
        )}
      </div>
    </div>
  )
}
