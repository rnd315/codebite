import { useNavigate, useLocation } from 'react-router-dom'
import { Sun, Moon, Zap, Users, GraduationCap, Hexagon } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'
import useAuth from '../../hooks/useAuth'
import { MAX_TOKENS } from '../../utils/constants'

export default function Navbar() {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { t } = useTranslation()
  const { theme, toggleTheme, lang, setLang, codeLang, setCodeLang, user, lives, streak } = useStore()
  const { logout } = useAuth()

  const handleLogout = () => { logout(); navigate('/') }

  const isLearning = pathname === '/pathway' || pathname.startsWith('/lesson') || pathname.startsWith('/module')
  const isCommunity = pathname === '/community'
  const activeTab = isCommunity ? 1 : 0

  return (
    <nav className="sticky top-0 z-40 border-b border-border/60 bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 lg:px-8">

        {/* Logo */}
        <button
          onClick={() => navigate('/pathway')}
          className="flex items-center gap-2.5 flex-shrink-0 hover:opacity-85 transition-opacity"
        >
          <div className="relative grid h-9 w-9 place-items-center rounded-xl glass">
            <span className="text-gradient font-mono text-sm font-bold">{'{·}'}</span>
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-accent shadow-[0_0_10px_var(--glow-accent)]" />
          </div>
          <div className="flex flex-col leading-none gap-0.5">
            <span className="font-mono text-xs font-bold text-foreground tracking-wide">
              codebite<span className="text-accent">•</span>
            </span>
            <span className="font-mono text-[9px] uppercase tracking-[0.28em] text-muted-foreground">
              v0.1 · dev-shell
            </span>
          </div>
        </button>

        {/* Center controls */}
        <div className="hidden md:flex items-center gap-3">

          {/* Code language toggle */}
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">LANG</span>
            <div className="relative inline-flex rounded-full glass p-0.5">
              <button
                onClick={() => setCodeLang('cpp')}
                className={`rounded-full px-3 py-1 text-xs font-mono font-semibold tracking-wide transition-all ${
                  codeLang === 'cpp'
                    ? 'bg-foreground text-background shadow-[0_0_20px_-6px_var(--glow-primary)]'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >C++</button>
              <button
                onClick={() => setCodeLang('python')}
                className={`rounded-full px-3 py-1 text-xs font-mono font-semibold tracking-wide transition-all ${
                  codeLang === 'python'
                    ? 'bg-foreground text-background shadow-[0_0_20px_-6px_var(--glow-primary)]'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >Python</button>
            </div>
          </div>

          {/* UI language toggle */}
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">UI</span>
            <div className="relative inline-flex rounded-full glass p-0.5">
              <button
                onClick={() => setLang('en')}
                className={`rounded-full px-3 py-1 text-xs font-mono font-semibold tracking-wide transition-all ${
                  lang === 'en'
                    ? 'bg-foreground text-background shadow-[0_0_20px_-6px_var(--glow-primary)]'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >EN</button>
              <button
                onClick={() => setLang('ro')}
                className={`rounded-full px-3 py-1 text-xs font-mono font-semibold tracking-wide transition-all ${
                  lang === 'ro'
                    ? 'bg-foreground text-background shadow-[0_0_20px_-6px_var(--glow-primary)]'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >RO</button>
            </div>
          </div>

          {/* Learning / Community segmented pill */}
          <div className="relative inline-flex items-center rounded-full glass p-1">
            {/* Sliding thumb */}
            <div
              className="absolute inset-y-1 rounded-full bg-gradient-to-r from-primary/90 to-accent/90 shadow-[0_0_30px_-4px_var(--glow-primary)] transition-transform duration-300"
              style={{
                width: 'calc(50% - 4px)',
                transform: activeTab === 0 ? 'translateX(2px)' : 'translateX(calc(100% + 6px))',
              }}
            />
            <button
              onClick={() => navigate('/pathway')}
              className={`relative z-10 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                isLearning ? 'text-background' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <GraduationCap size={14} />
              {t('nav.learning')}
            </button>
            <button
              onClick={() => navigate('/community')}
              className={`relative z-10 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                isCommunity ? 'text-background' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Users size={14} />
              {t('nav.guild')}
            </button>
          </div>
        </div>

        {/* Right: stat chips + controls */}
        <div className="flex items-center gap-2 flex-shrink-0">

          {/* Uptime chip */}
          <div className="hidden sm:inline-flex items-center gap-1.5 rounded-md glass px-2.5 py-1.5">
            <Zap size={13} className="text-streak" fill="oklch(var(--streak-ch) / 0.3)" strokeWidth={2.5} />
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">UPTIME</span>
            <span className="font-mono text-xs font-bold text-foreground">{streak}d</span>
          </div>

          {/* Tokens chip */}
          <div className="hidden sm:inline-flex items-center gap-1.5 rounded-md glass px-2.5 py-1.5">
            <Hexagon size={13} className="text-primary" fill="oklch(var(--primary-ch) / 0.3)" strokeWidth={2.5} />
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">TOKENS</span>
            <span className="font-mono text-xs font-bold text-foreground">{lives}/{MAX_TOKENS}</span>
          </div>

          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="grid h-9 w-9 place-items-center rounded-full glass hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
            title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
          >
            {theme === 'dark' ? <Moon size={15} /> : <Sun size={15} />}
          </button>

          {/* Avatar */}
          {user && (
            <button
              onClick={handleLogout}
              className="relative grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-xs font-black text-background ring-2 ring-background"
              title="Logout"
            >
              {user.username?.[0]?.toUpperCase() ?? '?'}
              <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-streak border-2 border-background" />
            </button>
          )}
        </div>

      </div>
    </nav>
  )
}
