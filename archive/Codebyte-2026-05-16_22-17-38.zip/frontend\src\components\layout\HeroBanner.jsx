import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { ArrowRight, Zap, Sparkles, Bot } from 'lucide-react'
import useStore from '../../store/useStore'

export default function HeroBanner({ lessons = [], completedCount = 0, currentLesson = null }) {
  const navigate = useNavigate()
  const { t } = useTranslation()
  const { xp, streak, lang } = useStore()

  const currentTitle = currentLesson
    ? (lang === 'ro' ? currentLesson.title_ro : currentLesson.title_en)
    : null

  const handleResume = () => {
    if (currentLesson) navigate(`/lesson/${currentLesson.slug}`)
  }

  return (
    <div className="relative overflow-hidden rounded-3xl glass-strong p-6 sm:p-8 mb-8">

      {/* Shimmer border ring */}
      <div
        aria-hidden
        className="pointer-events-none absolute -inset-px rounded-3xl opacity-60 animate-shimmer"
        style={{
          background: 'conic-gradient(from 120deg at 50% 50%, transparent 0deg, var(--glow-primary) 90deg, transparent 180deg, var(--glow-accent) 270deg, transparent 360deg)',
          maskImage: 'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)',
          WebkitMaskComposite: 'xor',
          maskComposite: 'exclude',
          padding: 1,
        }}
      />

      {/* Teal/accent aurora — fills center-right */}
      <div
        aria-hidden
        className="pointer-events-none absolute right-0 top-0 h-full w-3/4 blur-3xl opacity-35"
        style={{ background: 'radial-gradient(ellipse at 65% 50%, oklch(var(--accent-ch) / 0.40), transparent 65%)' }}
      />
      {/* Purple/primary halo — top-right corner */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-20 -top-24 h-80 w-80 rounded-full blur-3xl opacity-40"
        style={{ background: 'radial-gradient(closest-side, oklch(var(--primary-ch) / 0.60), transparent)' }}
      />

      {/* Content */}
      <div className="relative z-10">

        {/* CTA — absolute top-right */}
        {currentLesson && (
          <button
            onClick={handleResume}
            className="absolute -top-0 right-0 group flex items-center gap-2 bg-accent text-accent-foreground font-mono text-xs font-bold uppercase tracking-[0.12em] rounded-md px-5 py-3 hover:shadow-[0_0_40px_-4px_var(--glow-accent)] transition-all"
          >
            &gt;_ {t('hero.resumeBtn')}
            <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
          </button>
        )}

        {/* Eyebrow pill */}
        <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 mb-5">
          <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-primary" />
          <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-muted-foreground">
            {t('hero.session')}
          </span>
        </div>

        {/* Headlines */}
        <h1 className="font-mono text-3xl sm:text-5xl font-bold leading-[1.05] tracking-tight text-foreground">
          &gt; {t('hero.headline1')}
        </h1>
        <h1 className="font-mono text-3xl sm:text-5xl font-bold leading-[1.05] tracking-tight text-accent mb-4">
          {t('hero.headline2')}
        </h1>

        {/* Subtitle */}
        <p className="mt-2 max-w-xl text-sm text-muted-foreground sm:text-base mb-6 leading-relaxed">
          {currentLesson
            ? t('hero.progressText', { completed: completedCount, total: lessons.length, title: currentTitle })
            : t('hero.completedText', { total: lessons.length })}
        </p>

        {/* Stat chips */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-2.5 py-1 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <Zap size={12} className="text-primary" />
            {xp.toLocaleString()} {t('hero.xpWeek')}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-2.5 py-1 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <Sparkles size={12} className="text-primary" />
            {streak}D {t('hero.dayStreak')}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-2.5 py-1 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <Bot size={12} className="text-primary" />
            {t('hero.tutor')}
          </span>
        </div>

      </div>
    </div>
  )
}
