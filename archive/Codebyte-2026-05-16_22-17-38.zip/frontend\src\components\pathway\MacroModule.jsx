import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Lock, Terminal, CheckCircle2, Server } from 'lucide-react'

function MainframeBadge({ module, isActive, isCompleted }) {
  return (
    <div className="relative flex-shrink-0 flex flex-col items-center gap-1.5">
      {/* Glow halo behind badge when active */}
      {isActive && (
        <div
          className="absolute inset-0 rounded-xl blur-md animate-pulse-soft pointer-events-none"
          style={{ background: 'radial-gradient(closest-side, oklch(var(--accent-ch) / 0.28), transparent)' }}
        />
      )}
      <div className={`relative h-24 w-24 rounded-xl glass-strong ring-2 flex items-center justify-center overflow-hidden ${
        isActive ? 'ring-accent' : isCompleted ? 'ring-success' : 'ring-hairline'
      }`}>
        {/* Corner pin dots */}
        <span className="absolute top-1.5 left-1.5 h-1 w-1 rounded-full bg-hairline" />
        <span className="absolute top-1.5 right-1.5 h-1 w-1 rounded-full bg-hairline" />
        <span className="absolute bottom-1.5 left-1.5 h-1 w-1 rounded-full bg-hairline" />
        <span className="absolute bottom-1.5 right-1.5 h-1 w-1 rounded-full bg-hairline" />
        {/* Horizontal slats */}
        <div className="flex flex-col gap-2 w-12">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={`h-1.5 w-full rounded-sm transition-colors ${
                isActive ? 'bg-accent/70' : isCompleted ? 'bg-success/50' : 'bg-secondary/60'
              }`}
            />
          ))}
        </div>
      </div>
      <span className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
        {module.id.toUpperCase()}
      </span>
    </div>
  )
}

function LedRack({ completedCount, isActive, isCompleted }) {
  const rows = Array.from({ length: 6 }, (_, i) => i)
  return (
    <div className="flex-shrink-0 w-28">
      <div className="flex justify-between font-mono text-[8px] uppercase tracking-[0.15em] text-muted-foreground mb-2">
        <span>1U · SLOTS</span>
        <span>{isCompleted ? 'DONE' : isActive ? 'ONLINE' : '——'}</span>
      </div>
      <div className="space-y-1.5">
        {rows.map((i) => {
          const filled = i < completedCount
          const current = i === completedCount && isActive
          return (
            <div key={i} className="flex items-center gap-1.5">
              <span
                className={`h-1.5 w-1.5 rounded-full flex-shrink-0 ${
                  filled
                    ? 'bg-accent shadow-[0_0_6px_var(--accent)]'
                    : current
                    ? 'bg-primary/70'
                    : 'bg-hairline'
                }`}
              />
              <div className={`flex-1 h-px ${filled ? 'bg-accent/40' : current ? 'bg-primary/30' : 'bg-hairline'}`} />
              <span className="font-mono text-[8px] text-muted-foreground w-4 text-right">
                {String(i).padStart(2, '0')}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default function MacroModule({ module, lessons, completedIds, moduleStatus, lang }) {
  const navigate = useNavigate()
  const { t } = useTranslation()

  const isActive = moduleStatus === 'active'
  const isCompleted = moduleStatus === 'completed'
  const isLocked = moduleStatus === 'locked'

  const completedCount = lessons.filter((l) => completedIds.has(l.id)).length
  const xpTotal = lessons.length * 10
  const eta = Math.ceil(lessons.length * 0.25)
  const progressPct = lessons.length > 0 ? Math.round((completedCount / lessons.length) * 100) : 0

  const moduleTitle = module.label.split(' // ')[1] ?? module.label

  return (
    <div className={`relative overflow-hidden rounded-2xl border bg-background/60 transition-all ${
      isActive ? 'border-accent/40' : 'border-hairline'
    }`}>

      {/* Inner grid texture */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage: 'linear-gradient(to right, var(--grid-line) 1px, transparent 1px), linear-gradient(to bottom, var(--grid-line) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />

      {/* Active glow border */}
      {isActive && (
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-px rounded-2xl opacity-50 blur-2xl"
          style={{ background: 'var(--glow-accent)' }}
        />
      )}

      {/* Locked fog overlay */}
      {isLocked && (
        <div
          className="absolute inset-0 z-20 grid place-items-center"
          style={{ background: 'linear-gradient(180deg, oklch(0.10 0.03 265 / 70%) 0%, oklch(0.08 0.03 265 / 92%) 100%)' }}
        >
          <div aria-hidden className="absolute inset-0 bg-grid opacity-30" />
          <div className="relative flex flex-col items-center gap-3">
            <div className="relative h-16 w-16 rounded-xl glass grid place-items-center">
              <div
                className="absolute inset-0 rounded-xl blur-md opacity-50"
                style={{ background: 'radial-gradient(closest-side, var(--glow-primary), transparent)' }}
              />
              <Lock size={28} className="relative text-muted-foreground" />
            </div>
            <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              SECTOR LOCKED
            </span>
            <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground/60">
              {t('module.lockedMessage')}
            </span>
          </div>
        </div>
      )}

      {/* Header strip */}
      <div className="relative z-10 flex items-center justify-between border-b border-hairline bg-secondary/30 px-4 py-2">
        <div className="flex items-center gap-1.5">
          <Server size={11} className="text-muted-foreground" strokeWidth={2} />
          <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">
            RACK / {module.id.toUpperCase()}
          </span>
        </div>
        {isActive && (
          <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.15em] px-2 py-0.5 rounded bg-accent text-accent-foreground">
            <Terminal size={9} />
            ACTIVE
          </span>
        )}
        {isCompleted && (
          <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.15em] px-2 py-0.5 rounded bg-success/20 text-success border border-success/30">
            <CheckCircle2 size={9} />
            COMPLETE
          </span>
        )}
        {isLocked && (
          <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.15em] px-2 py-0.5 rounded border border-hairline bg-background/60 text-muted-foreground">
            <Lock size={9} />
            LOCKED
          </span>
        )}
      </div>

      {/* Card body — 3-column grid */}
      <div className="relative z-10 grid gap-5 p-5 md:grid-cols-[auto_1fr_auto] md:items-start">

        {/* Left: Mainframe badge */}
        <MainframeBadge module={module} isActive={isActive} isCompleted={isCompleted} />

        {/* Center: Module info */}
        <div className="min-w-0">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent mb-0.5">
            {module.id.toUpperCase()} //
          </p>
          <h2 className="font-mono text-2xl sm:text-3xl font-black tracking-tight text-foreground leading-tight">
            {moduleTitle}
          </h2>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground mt-1 mb-3">
            {module.subtitle}
          </p>

          {/* Meta row */}
          <div className="flex items-center gap-4 font-mono text-[11px] text-muted-foreground mb-3 uppercase tracking-[0.1em]">
            <span>UNITS <strong className="text-foreground font-bold ml-1">{lessons.length}</strong></span>
            <span>XP <strong className="text-foreground font-bold ml-1">
              {xpTotal >= 1000 ? `${(xpTotal / 1000).toFixed(1)}K` : xpTotal}
            </strong></span>
            <span>ETA <strong className="text-foreground font-bold ml-1">{eta}h</strong></span>
          </div>

          {/* Progress bar */}
          {(isActive || isCompleted) && lessons.length > 0 && (
            <div className="flex items-center gap-3">
              <div className="flex-1 h-1.5 rounded-full bg-secondary/60 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${isCompleted ? 'bg-success' : 'bg-accent'}`}
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <span className="font-mono text-[10px] text-muted-foreground flex-shrink-0">{progressPct}%</span>
            </div>
          )}
        </div>

        {/* Right: LED rack + action button */}
        <div className="flex flex-col gap-4 items-stretch">
          <LedRack
            completedCount={Math.min(completedCount, 6)}
            isActive={isActive}
            isCompleted={isCompleted}
          />

          {isActive && (
            <button
              onClick={() => navigate(`/module/${module.slug}`)}
              className="bg-accent text-accent-foreground font-mono text-xs font-bold uppercase tracking-[0.12em] rounded-md px-4 py-2.5 hover:shadow-[0_0_40px_-4px_var(--glow-accent)] transition-all text-center"
            >
              &gt; &gt; BOOT_MODULE &gt;
            </button>
          )}
          {isCompleted && (
            <button
              onClick={() => navigate(`/module/${module.slug}`)}
              className="bg-success/20 text-success font-mono text-xs font-bold uppercase tracking-[0.12em] rounded-md px-4 py-2.5 border border-success/30 hover:bg-success/30 transition-all text-center"
            >
              &gt; REVIEW_MODULE
            </button>
          )}
        </div>

      </div>
    </div>
  )
}
