import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Terminal, ChevronRight } from 'lucide-react'
import client from '../api/client'
import useStore from '../store/useStore'

export default function Onboarding() {
  const navigate = useNavigate()
  const syncFromUser = useStore((s) => s.syncFromUser)

  const [step, setStep] = useState('choice')      // 'choice' | 'test' | 'result'
  const [questions, setQuestions] = useState([])
  const [currentQ, setCurrentQ] = useState(0)
  const [answers, setAnswers] = useState({})      // { [questionId]: selectedIndex }
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)      // { passed, correct, total }

  // Step 1: user is a beginner — go straight to pathway
  const handleBeginner = () => navigate('/pathway')

  // Step 1: user wants to test their skills — fetch placement quiz
  const handleAdvanced = async () => {
    setLoading(true)
    try {
      const { data } = await client.get('/lessons/variables-basics')
      const qs = (data.quiz_questions ?? []).slice(0, 5)
      if (qs.length === 0) {
        navigate('/pathway')
        return
      }
      setQuestions(qs)
      setStep('test')
    } catch {
      navigate('/pathway')
    } finally {
      setLoading(false)
    }
  }

  // Step 2: user selects an answer option
  const handleSelectAnswer = (questionId, idx) => {
    setAnswers((prev) => ({ ...prev, [questionId]: idx }))
  }

  // Step 2: next question or finish
  const handleNext = () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ((q) => q + 1)
    } else {
      finishTest()
    }
  }

  const finishTest = async () => {
    const correct = questions.filter((q) => answers[q.id] === q.correct_index).length
    const passed = correct >= 3

    if (passed) {
      try {
        // Pre-complete all basics lessons so user starts at MOD_02
        const { data: allLessons } = await client.get('/lessons')
        const basics = allLessons.filter((l) => l.category === 'basics')
        await Promise.all(
          basics.map((l) =>
            client.post(`/progress/${l.id}`).catch(() => {})
          )
        )
        const { data: me } = await client.get('/auth/me')
        syncFromUser(me)
      } catch {}
    }

    setResult({ passed, correct, total: questions.length })
    setStep('result')
  }

  const currentQuestion = questions[currentQ]
  const lang = useStore((s) => s.lang)

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-dark-bg flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">

        {/* Header */}
        <div className="flex items-center gap-2 mb-8">
          <Terminal size={18} className="text-neon-cyan" />
          <span className="font-mono text-xs text-slate-500 uppercase tracking-widest">
            codebite / onboarding
          </span>
        </div>

        {/* ── Step: choice ── */}
        {step === 'choice' && (
          <div>
            <h1 className="font-mono text-2xl font-bold text-white mb-2">
              &gt;_ calibrate.exe
            </h1>
            <p className="text-slate-400 text-sm mb-8">
              Are you completely new to programming?
            </p>
            <div className="space-y-3">
              <button
                onClick={handleBeginner}
                className="w-full flex items-center gap-3 p-4 rounded-xl border border-dark-border bg-dark-card hover:border-neon-cyan/50 transition-all group text-left"
              >
                <span className="font-mono text-neon-cyan text-lg">▶</span>
                <div>
                  <p className="font-semibold text-white group-hover:text-neon-cyan transition-colors">
                    Start from scratch
                  </p>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    // Begin at MOD_01 — Foundations
                  </p>
                </div>
                <ChevronRight size={16} className="text-slate-600 ml-auto group-hover:text-neon-cyan transition-colors" />
              </button>

              <button
                onClick={handleAdvanced}
                disabled={loading}
                className="w-full flex items-center gap-3 p-4 rounded-xl border border-dark-border bg-dark-card hover:border-neon-purple/50 transition-all group text-left disabled:opacity-50"
              >
                <span className="font-mono text-neon-purple text-lg">&gt;_</span>
                <div>
                  <p className="font-semibold text-white group-hover:text-neon-purple transition-colors">
                    Test my skills
                  </p>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    // Run placement_test.exe — skip to MOD_02 if pass
                  </p>
                </div>
                <ChevronRight size={16} className="text-slate-600 ml-auto group-hover:text-neon-purple transition-colors" />
              </button>
            </div>
          </div>
        )}

        {/* ── Step: test ── */}
        {step === 'test' && currentQuestion && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <span className="font-mono text-xs text-slate-600 uppercase tracking-wider">
                placement_test.exe
              </span>
              <span className="font-mono text-xs text-slate-600">
                {currentQ + 1} / {questions.length}
              </span>
            </div>

            {/* Progress bar */}
            <div className="h-1 bg-dark-border rounded-full overflow-hidden mb-6">
              <div
                className="h-full bg-neon-cyan rounded-full transition-all duration-500"
                style={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
              />
            </div>

            <p className="text-white font-medium mb-5">
              {lang === 'ro' ? currentQuestion.question_ro : currentQuestion.question_en}
            </p>

            <div className="space-y-2 mb-6">
              {JSON.parse(currentQuestion.options_json).map((opt, idx) => {
                const label = lang === 'ro' ? opt.ro : opt.en
                const isSelected = answers[currentQuestion.id] === idx
                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectAnswer(currentQuestion.id, idx)}
                    className={`w-full text-left px-4 py-3 rounded-lg border text-sm font-mono transition-all ${
                      isSelected
                        ? 'border-neon-cyan bg-neon-cyan/10 text-neon-cyan'
                        : 'border-dark-border text-slate-400 hover:border-slate-600 hover:text-slate-200'
                    }`}
                  >
                    <span className="opacity-50 mr-2">{String.fromCharCode(65 + idx)}.</span>
                    {label}
                  </button>
                )
              })}
            </div>

            <button
              onClick={handleNext}
              disabled={answers[currentQuestion.id] === undefined}
              className="w-full font-mono text-sm font-semibold py-3 rounded-lg border border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-95"
            >
              {currentQ < questions.length - 1 ? '> next_question' : '> submit_test'}
            </button>
          </div>
        )}

        {/* ── Step: result ── */}
        {step === 'result' && result && (
          <div className="text-center">
            <p className={`font-mono text-4xl mb-3 ${result.passed ? 'text-neon-green' : 'text-slate-500'}`}>
              {result.passed ? '[PASS]' : '[FAIL]'}
            </p>
            <p className="font-mono text-slate-400 mb-1">
              {result.correct} / {result.total} correct
            </p>
            {result.passed ? (
              <p className="text-sm text-slate-400 mb-8">
                MOD_01 marked complete. You start at <span className="text-neon-cyan font-mono">MOD_02 // LOOPS & LOGIC</span>.
              </p>
            ) : (
              <p className="text-sm text-slate-400 mb-8">
                Begin at <span className="text-neon-cyan font-mono">MOD_01 // FOUNDATIONS</span> to build a solid base.
              </p>
            )}
            <button
              onClick={() => navigate('/pathway')}
              className="font-mono text-sm font-semibold px-6 py-3 rounded-lg border border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 transition-all active:scale-95"
            >
              &gt; launch_dashboard
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
