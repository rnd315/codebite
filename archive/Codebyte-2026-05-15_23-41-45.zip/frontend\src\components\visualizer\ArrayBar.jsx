import { motion } from 'framer-motion'

function getBarColor(index, step) {
  if (!step) return '#4b5563' // gray
  if (step.done) return '#39ff14' // neon green — sorted
  if (step.found === true && step.current === index) return '#39ff14' // found — green
  if (step.comparing?.includes(index)) {
    return step.swapped ? '#39ff14' : '#00e5ff' // swapped=green, comparing=cyan
  }
  if (step.mid === index) return '#00e5ff' // binary search mid
  if (step.current === index) return '#00e5ff' // linear search current
  if (step.low !== undefined && step.high !== undefined) {
    if (index >= step.low && index <= step.high) return '#6b7280' // in-range gray
    return '#374151' // out of range — darker
  }
  return '#4b5563'
}

export default function ArrayBar({ value, index, maxValue, step }) {
  const heightPct = Math.max(8, (value / maxValue) * 100)
  const color = getBarColor(index, step)

  return (
    <motion.div
      layout
      className="flex flex-col items-center justify-end gap-1 flex-1 min-w-0"
      style={{ height: '140px' }}
    >
      <span className="text-xs font-mono text-gray-400 truncate">{value}</span>
      <motion.div
        animate={{ height: `${heightPct}%`, backgroundColor: color }}
        transition={{ duration: 0.25 }}
        className="w-full rounded-t-sm"
        style={{ minHeight: '8px' }}
      />
    </motion.div>
  )
}
