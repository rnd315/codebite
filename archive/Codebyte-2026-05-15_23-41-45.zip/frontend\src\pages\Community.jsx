import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Plus, X } from 'lucide-react'
import client from '../api/client'
import useStore from '../store/useStore'
import QuestionCard from '../components/community/QuestionCard'
import Button from '../components/ui/Button'

export default function Community() {
  const { t } = useTranslation()
  const { setLives } = useStore()
  const [questions, setQuestions] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [newQuestion, setNewQuestion] = useState({ lesson_id: '', body: '' })
  const [lessons, setLessons] = useState([])
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [{ data: q }, { data: l }] = await Promise.all([
          client.get('/community/questions'),
          client.get('/lessons'),
        ])
        setQuestions(q)
        setLessons(l)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const handleAskQuestion = async (e) => {
    e.preventDefault()
    if (!newQuestion.body.trim() || !newQuestion.lesson_id) return
    setSubmitting(true)
    try {
      const { data } = await client.post('/community/questions', {
        lesson_id: parseInt(newQuestion.lesson_id),
        body: newQuestion.body.trim(),
      })
      setQuestions((p) => [data, ...p])
      setNewQuestion({ lesson_id: '', body: '' })
      setShowForm(false)
    } finally {
      setSubmitting(false)
    }
  }

  const handleAnswerAccepted = async () => {
    // Refresh user lives after an answer is accepted
    try {
      const { data: me } = await client.get('/auth/me')
      setLives(me.lives)
    } catch {}
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-gray-400">{t('common.loading')}</div>
    )
  }

  return (
    <div className="py-6 max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">{t('community.title')}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t('community.description')}</p>
        </div>
        <Button onClick={() => setShowForm((p) => !p)} size="sm" variant={showForm ? 'ghost' : 'primary'}>
          {showForm ? <><X size={16} /> {t('common.cancel')}</> : <><Plus size={16} /> {t('community.askQuestion')}</>}
        </Button>
      </div>

      {/* Ask question form */}
      {showForm && (
        <form
          onSubmit={handleAskQuestion}
          className="bg-white dark:bg-dark-card border border-gray-200 dark:border-dark-border rounded-xl p-4 space-y-3"
        >
          <select
            value={newQuestion.lesson_id}
            onChange={(e) => setNewQuestion((p) => ({ ...p, lesson_id: e.target.value }))}
            required
            className="w-full bg-gray-100 dark:bg-dark-bg border border-gray-200 dark:border-dark-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-neon-cyan"
          >
            <option value="">{t('community.forLesson')}...</option>
            {lessons.map((l) => (
              <option key={l.id} value={l.id}>{l.title_en}</option>
            ))}
          </select>
          <textarea
            value={newQuestion.body}
            onChange={(e) => setNewQuestion((p) => ({ ...p, body: e.target.value }))}
            placeholder={t('community.questionPlaceholder')}
            rows={3}
            required
            className="w-full bg-gray-100 dark:bg-dark-bg border border-gray-200 dark:border-dark-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-neon-cyan resize-none"
          />
          <Button type="submit" disabled={submitting || !newQuestion.body.trim() || !newQuestion.lesson_id}>
            {submitting ? '...' : t('community.submit')}
          </Button>
        </form>
      )}

      {/* Questions list */}
      {questions.length === 0 ? (
        <p className="text-center text-gray-400 py-10">{t('community.noQuestions')}</p>
      ) : (
        <div className="space-y-3">
          {questions.map((q) => (
            <QuestionCard key={q.id} question={q} onAnswerAccepted={handleAnswerAccepted} />
          ))}
        </div>
      )}
    </div>
  )
}
