import { useNavigate, useLocation } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Map, MessageCircle, User } from 'lucide-react'

const TABS = [
  { path: '/pathway', icon: Map, key: 'nav.pathway' },
  { path: '/community', icon: MessageCircle, key: 'nav.community' },
  { path: '/profile', icon: User, key: 'nav.profile' },
]

export default function MobileNav() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const { pathname } = useLocation()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 sm:hidden h-16 bg-white dark:bg-dark-card border-t border-gray-200 dark:border-dark-border flex items-center">
      {TABS.map(({ path, icon: Icon, key }) => {
        const active = pathname === path || pathname.startsWith(path + '/')
        return (
          <button
            key={path}
            onClick={() => navigate(path)}
            className={`flex-1 h-full flex flex-col items-center justify-center gap-0.5 text-xs transition-colors
              ${active
                ? 'text-neon-cyan'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
              }`}
          >
            <Icon size={20} strokeWidth={active ? 2.5 : 1.8} />
            <span>{t(key)}</span>
          </button>
        )
      })}
    </nav>
  )
}
