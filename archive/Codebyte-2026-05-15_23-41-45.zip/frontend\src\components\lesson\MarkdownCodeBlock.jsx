import { useState } from 'react'
import useStore from '../../store/useStore'

export default function MarkdownCodeBlock({ className, children }) {
  const codeLang = useStore((s) => s.codeLang)
  const [copied, setCopied] = useState(false)

  const lang = /language-(\w+)/.exec(className || '')?.[1]

  // Hide cpp blocks when Python is selected, and vice versa
  if (lang === 'cpp' && codeLang !== 'cpp') return null
  if (lang === 'python' && codeLang !== 'python') return null

  const code = String(children).replace(/\n$/, '')

  const handleCopy = () => {
    navigator.clipboard?.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const langLabel = lang === 'cpp' ? 'C++' : lang

  return (
    <div className="my-4 rounded-lg overflow-hidden border border-dark-border not-prose">
      {lang && (
        <div className="flex items-center justify-between px-4 py-1.5 bg-dark-border text-xs font-mono text-gray-400 border-b border-dark-border">
          <span className="text-neon-cyan">{langLabel}</span>
          <button
            onClick={handleCopy}
            className="hover:text-neon-cyan transition-colors"
          >
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>
      )}
      <pre className="p-4 overflow-x-auto bg-dark-bg text-sm font-mono text-gray-200 leading-relaxed m-0">
        <code>{code}</code>
      </pre>
    </div>
  )
}
