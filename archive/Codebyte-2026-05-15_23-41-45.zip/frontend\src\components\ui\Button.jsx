const VARIANTS = {
  primary:
    'bg-neon-cyan text-dark-bg font-semibold hover:brightness-110 active:scale-95 shadow-md',
  ghost:
    'border border-dark-border text-gray-300 hover:border-neon-cyan hover:text-neon-cyan dark:border-dark-border',
  danger:
    'bg-red-600 text-white hover:bg-red-500 active:scale-95',
  success:
    'bg-neon-green text-dark-bg font-semibold hover:brightness-110 active:scale-95',
}

const SIZES = {
  sm: 'text-sm px-3 py-1.5 min-h-[36px]',
  md: 'text-base px-4 py-2.5 min-h-[44px]',
  lg: 'text-lg px-6 py-3 min-h-[52px]',
}

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  disabled = false,
  ...props
}) {
  return (
    <button
      className={`
        inline-flex items-center justify-center gap-2 rounded-lg
        transition-all duration-150 cursor-pointer select-none
        disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100
        ${VARIANTS[variant]}
        ${SIZES[size]}
        ${className}
      `}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  )
}
