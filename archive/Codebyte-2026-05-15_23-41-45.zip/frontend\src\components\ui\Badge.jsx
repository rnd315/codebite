const COLOR_MAP = {
  basics: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  sorting: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  searching: 'bg-neon-cyan/20 text-neon-cyan border-neon-cyan/30',
  'arrays & strings': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  recursion: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  primes: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  complexity: 'bg-green-500/20 text-green-400 border-green-500/30',
  easy: 'bg-green-500/20 text-green-400 border-green-500/30',
  medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  hard: 'bg-red-500/20 text-red-400 border-red-500/30',
}

export default function Badge({ label, type = '', className = '' }) {
  const color = COLOR_MAP[type?.toLowerCase()] ?? 'bg-gray-500/20 text-gray-400 border-gray-500/30'
  return (
    <span
      className={`inline-block text-xs font-medium px-2.5 py-0.5 rounded-full border ${color} ${className}`}
    >
      {label}
    </span>
  )
}
