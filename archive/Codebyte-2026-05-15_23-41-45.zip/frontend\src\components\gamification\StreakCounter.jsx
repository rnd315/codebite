import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'

export default function StreakCounter() {
  const { t } = useTranslation()
  const streak = useStore((s) => s.streak)

  return (
    <div
      className="flex items-center gap-1 text-sm font-semibold text-orange-400"
      title={`${streak} ${t('gamification.streak')}`}
    >
      <span>🔥</span>
      <span>{streak}</span>
    </div>
  )
}
