import { Heart } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'
import { MAX_LIVES } from '../../utils/constants'

export default function LivesDisplay() {
  const { t } = useTranslation()
  const lives = useStore((s) => s.lives)

  return (
    <div className="flex items-center gap-1" title={`${lives} ${t('gamification.lives')}`}>
      {Array.from({ length: MAX_LIVES }).map((_, i) => (
        <Heart
          key={i}
          size={16}
          className={i < lives ? 'text-red-500 fill-red-500' : 'text-gray-600 fill-transparent'}
        />
      ))}
    </div>
  )
}
