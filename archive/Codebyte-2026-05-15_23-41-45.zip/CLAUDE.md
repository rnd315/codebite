# CLAUDE.md — CodeBite Project Memory & Guidelines

> This file is the single source of truth for all Claude Code sessions.
> Read this before touching any file. No exceptions.

---

## 1. Project Context

**Name:** CodeBite (CodeByte)
**Type:** Gamified educational web app — "Duolingo for algorithms"
**Goal:** Teach programming logic and algorithms (C++ and Python) through bite-sized lessons,
interactive visualizations, and exercises.
**Competition:** InfoEducație Romania — "Educational Software" category.
The jury evaluates: modularity, Git discipline, scientific accuracy, interactivity, and explainability.
**Deadline:** 1-week MVP. Ship clean, working code — not perfect code.
**Production target:** Linux VPS, served by Nginx.

---

## 2. Tech Stack

### Backend (Python — primary language)
| Layer        | Choice                        | Notes                                      |
|--------------|-------------------------------|--------------------------------------------|
| Framework    | FastAPI                       | Async, fast, auto-generates OpenAPI docs   |
| Database     | SQLite via SQLAlchemy (async) | Local file, zero cost, jury-safe           |
| Auth         | JWT (python-jose + passlib)   | Simple, no third-party service             |
| Migrations   | Alembic                       | Schema versioning, required for Git discipline |
| Server       | Uvicorn                       | ASGI server for FastAPI                    |

### Frontend (React — unavoidable for the visualizer)
| Layer        | Choice                        | Notes                                      |
|--------------|-------------------------------|--------------------------------------------|
| Build tool   | Vite                          | Fast HMR, no CRA                          |
| UI           | React 18                      | Component-based, jury-friendly             |
| Styling      | Tailwind CSS only             | No NanoCSS, no extra CSS frameworks        |
| Icons        | lucide-react                  | Lightweight, consistent                    |
| State        | Zustand                       | Lives, streaks, theme, language, code lang |
| Routing      | React Router v6               | SPA navigation                             |
| Animation    | Framer Motion                 | Algorithm visualizer step-through          |
| i18n         | react-i18next                 | EN/RO toggle — wired from Day 1            |

### Infrastructure
| Layer        | Choice                        |
|--------------|-------------------------------|
| VPS OS       | Linux (Ubuntu LTS)            |
| Web server   | Nginx (reverse proxy)         |
| Process mgr  | systemd or PM2 for Uvicorn    |

### No paid services. No Supabase. No Vercel. No external auth providers.

---

## 3. Project Structure

```
codebite/
├── backend/
│   ├── main.py                  # FastAPI app entry point
│   ├── database.py              # SQLAlchemy async engine + session
│   ├── dependencies.py          # get_current_user FastAPI dependency
│   ├── constants.py             # XP_PER_LESSON, XP_PER_QUIZ, MAX_LIVES, etc.
│   ├── models/
│   │   ├── user.py
│   │   ├── lesson.py            # Lesson + QuizQuestion models
│   │   ├── progress.py
│   │   └── community.py
│   ├── routers/
│   │   ├── auth.py              # /auth/register, /auth/login, /auth/me
│   │   ├── lessons.py           # /lessons, /lessons/{slug}
│   │   ├── progress.py          # /progress, /progress/{id}, /progress/{id}/quiz
│   │   └── community.py         # /community/questions, /community/answers
│   ├── schemas/                 # Pydantic request/response models
│   ├── crud/                    # DB operations, separated from routers
│   ├── core/
│   │   ├── config.py            # Settings (JWT secret, DB URL, CORS)
│   │   └── security.py          # Password hashing, JWT encode/decode
│   ├── alembic/                 # DB migrations
│   │   └── versions/001_initial_schema.py
│   ├── alembic.ini
│   ├── seed.py                  # Populates 5 lessons + quiz questions — run once
│   ├── create_test_user.py      # Creates demo/Demo1234 test account — run once
│   ├── .venv/                   # Python virtual environment — never commit
│   └── codebite.db              # SQLite file — NEVER commit to Git
│
├── frontend/
│   ├── public/
│   │   └── locales/
│   │       ├── en/translation.json
│   │       └── ro/translation.json
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── api/
│   │   │   └── client.js        # Axios instance with base URL + JWT interceptor
│   │   ├── store/
│   │   │   └── useStore.js      # Zustand store — single file
│   │   ├── components/
│   │   │   ├── ui/              # Reusable: Button, Card, Badge, Modal, ProgressBar
│   │   │   ├── layout/          # Navbar, Sidebar, MobileNav
│   │   │   ├── gamification/    # LivesDisplay, StreakCounter, XPBar
│   │   │   ├── visualizer/      # AlgorithmVisualizer, ArrayBar, StepControls
│   │   │   ├── lesson/          # LessonCard, LessonNode, CodeBlock, QuizQuestion
│   │   │   └── community/       # QuestionCard, AnswerForm, VoteButton
│   │   ├── pages/
│   │   │   ├── Home.jsx         # Landing / login gate
│   │   │   ├── Pathway.jsx      # Visual roadmap of lesson nodes
│   │   │   ├── Lesson.jsx       # Lesson detail: theory + exercise + visualizer
│   │   │   ├── Community.jsx    # Q&A feed
│   │   │   └── Profile.jsx      # User stats, streak calendar
│   │   ├── hooks/
│   │   │   ├── useAuth.js
│   │   │   ├── useLives.js
│   │   │   └── useVisualizer.js # Step-through logic, isolated from UI
│   │   └── utils/
│   │       ├── algorithms.js    # Pure algorithm implementations (for visualizer)
│   │       └── constants.js     # Lesson IDs, max lives, streak rules
│   ├── index.html
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── scripts/
│   ├── start.ps1                # Windows dev launcher (opens 2 PS windows)
│   └── start.sh                 # Linux/VPS dev launcher
├── .env                         # Never commit. JWT_SECRET, DB_URL
├── .gitignore
├── README.md
└── CLAUDE.md                    # This file
```

---

## 4. Data Models (SQLite via SQLAlchemy)

> Full column definitions live in `backend/models/`. This section captures purpose,
> relationships, and non-obvious design decisions only. Update both here and the models
> when the schema changes — Alembic migrations are the authoritative source of truth.

| Model | Purpose | Key relationships |
|---|---|---|
| `users` | Account, gamification state (lives, streak, XP) | has many `user_progress`, `questions`, `answers` |
| `lessons` | Lesson metadata + bilingual content | has many `user_progress`, `quiz_questions`, `questions` |
| `quiz_questions` | Multiple-choice questions scoped to a lesson | belongs to `lessons` |
| `user_progress` | Per-user completion state for each lesson | belongs to `users` + `lessons`; UNIQUE(user_id, lesson_id) |
| `questions` | Community Q&A questions scoped to a lesson | belongs to `users` + `lessons`; has many `answers` |
| `answers` | Answers to community questions | belongs to `questions` + `users` |

### Non-obvious design decisions

- **`users.last_active`** — date only (not datetime); used to detect if a day was missed for streak reset at midnight.
- **`user_progress` UNIQUE(user_id, lesson_id)** — `POST /progress/{lesson_id}` is idempotent; re-completing a lesson updates score but doesn't duplicate rows.
- **`answers.accepted`** — when the question author marks an answer accepted, the answerer gains +1 life (capped at 5). This is the core community-gamification hook.
- **`lessons.content_en` / `lessons.content_ro`** — full lesson body stored as Markdown text. Both columns required; no fallback to English if Romanian is missing.
- **`quiz_questions.options_json`** — stored as a JSON array of `{en, ro}` objects so option text is bilingual. `correct_index` is a zero-based integer into that array.
- **`quiz_questions.explanation_en` / `explanation_ro`** — shown after a wrong answer to explain the correct choice. Required for jury "scientific accuracy" criterion.

---

## 5. Core Feature Specifications

### 5.1 Gamification Rules
- **Lives:** Start at 5. Lost on wrong quiz answer. Max 5. Regained by having your answer accepted in Q&A.
- **Streaks:** Increment when user completes at least 1 lesson per day. Reset at midnight if no activity.
- **XP:** +10 per completed lesson, +5 per correct quiz attempt, +15 per accepted answer.
- **No purchases. No ads. No paywalls.** Everything is earned.

### 5.2 The Pathway
- Visual top-to-bottom roadmap of lesson nodes.
- Nodes: locked (gray), available (neon), completed (green checkmark).
- Unlock rule: complete the previous node to unlock the next.
- Mobile: nodes stacked vertically, full-width, tap to open.

### 5.3 Algorithm Visualizer (Most Important Feature)
- Isolated hook `useVisualizer.js` drives all state: array, currentStep, stepHistory.
- UI (`AlgorithmVisualizer.jsx`) only renders what the hook exposes.
- Controls: Play, Pause, Step Forward, Step Back, Reset, Speed Slider.
- Algorithms to implement for MVP: Bubble Sort, Linear Search, Binary Search.
- Each step annotates what is happening (e.g., "Comparing index 2 and 3").
- Both C++ and Python pseudocode shown alongside — controlled by global toggle.
- Framer Motion animates array bar swaps/highlights only. Logic stays pure JS.

### 5.4 Language Toggle (EN/RO)
- Powered by react-i18next.
- All user-facing strings go through `t('key')` — no hardcoded English/Romanian.
- Translation files live in `public/locales/en/` and `public/locales/ro/`.
- Default: detect browser language, fallback to EN.
- **Day 1 requirement: scaffold i18n before writing any page content.**

### 5.5 Code Language Toggle (C++ / Python)
- Global Zustand state: `codeLang: 'cpp' | 'python'`
- `CodeBlock` component reads this state and renders the correct snippet.
- Code snippets are stored as `{ cpp: '...', python: '...' }` objects in lesson data.

### 5.6 Dark / Light Mode
- Global Zustand state: `theme: 'dark' | 'light'`
- Toggled via Tailwind's `dark:` classes — set `darkMode: 'class'` in tailwind.config.js.
- Default: dark mode (cyberpunk aesthetic).
- Persisted to localStorage via Zustand persist middleware.

### 5.7 Community Q&A
- Users post questions scoped to a lesson.
- Other users answer.
- Question author marks one answer as "accepted" → answerer gains +1 life (max 5).
- No voting system in MVP — keep it simple.

### 5.8 Olympiad Curriculum Scope

Full product topic categories (not all ship in MVP — see section 9 for MVP scope):

| Category | Topics |
|---|---|
| Basics | Variables, data types, loops, conditionals, functions |
| Arrays & strings | Traversal, manipulation, two-pointer patterns |
| Sorting | Bubble, Selection, Insertion, Merge, Quick |
| Searching | Linear search, Binary search |
| Prime numbers & divisibility | Sieve of Eratosthenes, GCD, LCM |
| Recursion | Factorial, Fibonacci, recursive vs iterative |
| Complexity | O(n), O(n²), O(log n) — analysis, not proof |

**Explicitly out of scope for V1:** graphs, trees, dynamic programming, greedy algorithms.
These require a separate problem-solving interface beyond what the lesson/visualizer model supports.

---

## 6. API Endpoints (FastAPI)

```
GET    /                      — API info + links (dev convenience)
GET    /health                — health check

POST   /auth/register         — create user
POST   /auth/login            — returns JWT + user object
GET    /auth/me               — returns current user (JWT required)

GET    /lessons               — all lessons (ordered by order_index)
GET    /lessons/{slug}        — single lesson with content + quiz questions

GET    /progress              — current user's full progress
POST   /progress/{lesson_id} — mark lesson completed, update streak + XP (+10)
POST   /progress/{lesson_id}/quiz — submit quiz answer; correct → +5 XP,
                                    wrong → −1 life; returns correct_index + explanation

GET    /community/questions              — all questions
GET    /community/questions/{id}/answers — answers for a question
POST   /community/questions             — ask a question
POST   /community/answers/{question_id} — post an answer
PATCH  /community/answers/{answer_id}/accept — accept answer (+1 life to answerer, +15 XP)
```

---

## 7. Strict Coding Guidelines

### General
- **Modular first.** Every component does one thing. If a component exceeds ~150 lines, split it.
- **No logic in JSX.** Move conditionals and computations to hooks or utils.
- **Descriptive names.** `handleAnswerAccept` not `handleClick2`. `isLessonLocked` not `flag`.
- **Brief comments on complex logic** — the jury will ask you to explain your code.
- **No console.log in commits.** Use a `debug` flag in constants.js if needed during dev.

### React / Frontend
- Functional components only. No class components.
- Custom hooks for all stateful logic (`useVisualizer`, `useAuth`, `useLives`).
- Zustand store in one file. No Redux. No Context API for global state.
- All API calls go through `src/api/client.js` — never fetch() inline in components.
- Tailwind only for styling. No inline `style={{}}` except for dynamic values (e.g., bar heights in visualizer).
- Mobile-first Tailwind: write `sm:` / `md:` breakpoints after the base mobile style.

### Python / Backend
- One router file per domain (auth, lessons, progress, community).
- CRUD operations live in `crud/` — never inside routers.
- Pydantic schemas validate every request and response.
- All DB operations are async (`async def`, `await session.execute(...)`).
- Passwords always hashed with bcrypt. JWT secret from `.env`, never hardcoded.
- Return consistent error shapes: `{ "detail": "message" }`.
- **bcrypt must be pinned to `==4.0.1`** — passlib 1.7.4 is incompatible with bcrypt ≥ 4.0.0
  (reads `bcrypt.__about__.__version__` which was removed). Never upgrade bcrypt without
  upgrading passlib first.
- **SQLAlchemy must be `>=2.0.36`** — earlier versions break on Python 3.13 due to a
  `FastIntFlag.__firstlineno__` conflict. The project runs Python 3.13.

### Database
- Run Alembic for every schema change. Never edit the DB manually in production.
- Foreign key constraints always defined.
- Add indexes on `user_id`, `lesson_id` columns used in JOINs.

### Git
- Commit format: `feat:`, `fix:`, `refactor:`, `docs:`, `style:`
- Commit after each working feature. Never commit broken code to main.
- `.env` and `codebite.db` are in `.gitignore` — always.
- Branch strategy: `main` (stable), `dev` (active), feature branches off `dev`.

---

## 8. UI / Design Rules

- **Aesthetic:** Dark cyberpunk/neon as default. Clean Duolingo-style layout on light mode.
- **Primary colors (dark):** Background `#0f0f1a`, accent neon green `#39ff14` or cyan `#00e5ff`.
- **Mobile-first layout.** Every page must work on a 375px wide screen.
- **Navbar:** Fixed top. Shows lives (hearts), streak (flame), XP, and avatar initial.
- **Lesson nodes on pathway:** Round cards, tap/click opens lesson. Clear locked/unlocked/done states.
- **Visualizer bars:** Colored rectangles, height = value. Highlighted bars in accent color during active comparison.
- **Buttons:** Large tap targets (min 44px height) for mobile usability.
- **No horizontal scroll** on any page at any screen size.

---

## 9. MVP Scope (1-Week Plan)

| Day | Deliverable                                                  |
|-----|--------------------------------------------------------------|
| 1   | Project scaffold, FastAPI + SQLite + Alembic, Vite + Tailwind + Zustand + i18n wired |
| 2   | Auth (register/login/JWT), Zustand auth store, protected routes |
| 3   | Pathway page + 5 lesson nodes (static content), lesson detail page |
| 4   | Algorithm Visualizer (Bubble Sort) + C++/Python toggle       |
| 5   | Lives + Streak logic wired to backend, quiz component        |
| 6   | Community Q&A (ask + answer + accept)                        |
| 7   | Polish, dark/light toggle, EN/RO toggle, mobile fixes, deploy to VPS |

**Out of scope for MVP:** leaderboards, email verification, push notifications, payments, in-browser code execution (students read and study code snippets but cannot run them — a sandboxed runner such as Judge0 is a V2 feature).

---

## 10. Deployment (Nginx on Cloud Linux VPS)

### Local development (no Nginx)

**Quickstart (Windows):**
```powershell
.\scripts\start.ps1   # opens two PowerShell windows: backend + frontend
```

**Quickstart (Linux/Mac):**
```bash
bash scripts/start.sh
```

**Manual start:**
```bash
# Backend (activate venv first)
cd backend
.venv\Scripts\uvicorn main:app --reload --port 8000   # Windows
# .venv/bin/uvicorn main:app --reload --port 8000     # Linux/Mac

# Frontend (separate terminal)
cd frontend && npm run dev   # Vite dev server on :5173
```

**Dev URLs:**
| URL | What it is |
|-----|-----------|
| http://localhost:5173 | The app (React frontend) — go here |
| http://localhost:8000 | FastAPI backend API — not the app |
| http://localhost:8000/docs | Interactive Swagger API docs |

Frontend `vite.config.js` proxies `/api` → `http://localhost:8000` (strips the `/api` prefix).
On Windows, `npm` is a `.ps1` script — always invoke it via `powershell.exe` or a terminal,
never via `Start-Process -FilePath "npm"` directly.

**First-time setup:**
```bash
cd backend
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt   # Windows
.venv\Scripts\alembic upgrade head
.venv\Scripts\python seed.py                    # seeds 5 lessons
.venv\Scripts\python create_test_user.py        # creates demo/Demo1234

cd ../frontend
npm install
```

### Production (cloud Linux VPS — Ubuntu LTS)

```nginx
# /etc/nginx/sites-available/codebite

server {
    listen 80;
    server_name yourdomain.com;

    # Frontend (built React app)
    location / {
        root /var/www/codebite/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # Backend (FastAPI via Uvicorn)
    location /api/ {
        proxy_pass http://127.0.0.1:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

- FastAPI runs on port 8000 via systemd service.
- React is built (`npm run build`) and served as static files.
- SQLite DB file stored at `/var/www/codebite/backend/codebite.db` — outside web root.
- Add HTTPS via Certbot (Let's Encrypt) before competition demo.

---

## 11. What the Jury Evaluates (Keep in Mind Always)

1. **Modularity** — can you point to isolated, single-purpose components?
2. **Git history** — does commit history tell a story of disciplined development?
3. **Scientific accuracy** — are algorithm explanations and visualizations correct?
4. **Interactivity** — does the visualizer actually teach, not just display?
5. **Originality** — community Q&A earning lives is a differentiator. Highlight it.
6. **Code explainability** — can you walk through any function and explain it in 30 seconds?

---

*Last updated: after full MVP implementation — project structure reflects actual files, API endpoints are complete, Python 3.13 + bcrypt compatibility pinned, dev workflow clarified with scripts/ directory. Update this file whenever architecture decisions change.*