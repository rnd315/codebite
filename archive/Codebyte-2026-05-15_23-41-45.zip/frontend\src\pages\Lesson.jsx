import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import ReactMarkdown from 'react-markdown'
import { ArrowLeft, CheckCircle2 } from 'lucide-react'
import MarkdownCodeBlock from '../components/lesson/MarkdownCodeBlock'
import client from '../api/client'
import useStore from '../store/useStore'
import Button from '../components/ui/Button'
import Badge from '../components/ui/Badge'
import AlgorithmVisualizer from '../components/visualizer/AlgorithmVisualizer'
import QuizQuestion from '../components/lesson/QuizQuestion'

export default function Lesson() {
  const { slug } = useParams()
  const { t } = useTranslation()
  const navigate = useNavigate()
  const lang = useStore((s) => s.lang)
  const { setXp, setStreak } = useStore()

  const [lesson, setLesson] = useState(null)
  const [loading, setLoading] = useState(true)
  const [completing, setCompleting] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    client.get(`/lessons/${slug}`)
      .then(({ data }) => setLesson(data))
      .catch(() => setError(t('common.error')))
      .finally(() => setLoading(false))
  }, [slug, t])

  const handleComplete = async () => {
    if (completed || completing) return
    setCompleting(true)
    try {
      await client.post(`/progress/${lesson.id}`, { score: 100, attempts: 1 })
      const { data: me } = await client.get('/auth/me')
      setXp(me.xp)
      setStreak(me.streak)
      setCompleted(true)
    } catch {
      // Ignore — may already be completed
      setCompleted(true)
    } finally {
      setCompleting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-gray-400">{t('common.loading')}</div>
    )
  }
  if (error || !lesson) {
    return <p className="text-center text-red-400 py-10">{error ?? t('common.error')}</p>
  }

  const title = lang === 'ro' ? lesson.title_ro : lesson.title_en
  const content = lang === 'ro' ? lesson.content_ro : lesson.content_en

  return (
    <div className="py-6 max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <button
          onClick={() => navigate('/pathway')}
          className="flex items-center gap-1 text-sm text-gray-400 hover:text-neon-cyan transition-colors mt-1"
        >
          <ArrowLeft size={16} />
          {t('lesson.back')}
        </button>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge label={lesson.category} type={lesson.category} />
          {lesson.has_visualizer && (
            <span className="text-xs text-neon-cyan font-mono">⚡ visualizer</span>
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold">{title}</h1>
      </div>

      {/* Lesson content (Markdown) */}
      <article className="prose prose-sm sm:prose dark:prose-invert max-w-none
        prose-code:text-neon-cyan prose-code:bg-dark-bg prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
        prose-pre:bg-transparent prose-pre:p-0 prose-pre:border-0">
        <ReactMarkdown
          components={{
            code({ className, children, ...props }) {
              const isBlock = /language-/.test(className || '')
              if (isBlock) {
                return (
                  <MarkdownCodeBlock className={className}>
                    {children}
                  </MarkdownCodeBlock>
                )
              }
              return (
                <code
                  className="text-neon-cyan bg-dark-bg px-1.5 py-0.5 rounded text-sm font-mono"
                  {...props}
                >
                  {children}
                </code>
              )
            },
          }}
        >
          {content}
        </ReactMarkdown>
      </article>

      {/* Algorithm visualizer */}
      {lesson.has_visualizer && (
        <div>
          <h2 className="text-lg font-semibold mb-3">{t('lesson.visualizer')}</h2>
          <AlgorithmVisualizer lessonSlug={lesson.slug} />
        </div>
      )}

      {/* Quiz */}
      {lesson.quiz_questions?.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold mb-3">{t('lesson.quiz')}</h2>
          <div className="space-y-4">
            {lesson.quiz_questions.map((q, i) => (
              <QuizQuestion
                key={q.id}
                question={q}
                lessonId={lesson.id}
                index={i}
                total={lesson.quiz_questions.length}
                lang={lang}
              />
            ))}
          </div>
        </div>
      )}

      {/* Complete button */}
      <div className="pt-2 pb-4">
        {completed ? (
          <div className="flex items-center gap-2 justify-center text-green-500 font-medium py-3">
            <CheckCircle2 size={20} />
            {t('lesson.completed')}
          </div>
        ) : (
          <Button
            onClick={handleComplete}
            disabled={completing}
            variant="success"
            className="w-full"
          >
            {completing ? t('lesson.completing') : t('lesson.markComplete')}
          </Button>
        )}
      </div>
    </div>
  )
}
