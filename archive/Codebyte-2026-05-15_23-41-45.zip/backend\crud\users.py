from datetime import date
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from models.user import User
from core.security import hash_password

MAX_LIVES = 5


async def get_by_id(db: AsyncSession, user_id: int) -> Optional[User]:
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def get_by_email(db: AsyncSession, email: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def get_by_username(db: AsyncSession, username: str) -> Optional[User]:
    result = await db.execute(select(User).where(User.username == username))
    return result.scalar_one_or_none()


async def create_user(db: AsyncSession, username: str, email: str, password: str) -> User:
    user = User(username=username, email=email, hashed_password=hash_password(password))
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def decrement_lives(db: AsyncSession, user: User) -> User:
    if user.lives > 0:
        user.lives -= 1
        await db.commit()
        await db.refresh(user)
    return user


async def increment_lives(db: AsyncSession, user: User) -> User:
    if user.lives < MAX_LIVES:
        user.lives += 1
        await db.commit()
        await db.refresh(user)
    return user


async def add_xp(db: AsyncSession, user: User, amount: int) -> User:
    user.xp += amount
    await db.commit()
    await db.refresh(user)
    return user


async def update_streak_and_xp(db: AsyncSession, user: User, xp_gain: int) -> User:
    """Called on lesson completion. Updates streak based on last_active date."""
    today = date.today()
    if user.last_active is None:
        user.streak = 1
    elif user.last_active == today:
        pass  # already active today, streak unchanged
    elif (today - user.last_active).days == 1:
        user.streak += 1
    else:
        user.streak = 1  # missed a day — reset

    user.last_active = today
    user.xp += xp_gain
    await db.commit()
    await db.refresh(user)
    return user
