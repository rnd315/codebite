import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import client from '../api/client'
import useStore from '../store/useStore'
import LessonNode from '../components/lesson/LessonNode'

function computeStatus(lesson, completedIds, allLessons) {
  if (completedIds.has(lesson.id)) return 'completed'
  const prev = allLessons.find((l) => l.order_index === lesson.order_index - 1)
  if (!prev || completedIds.has(prev.id)) return 'available'
  return 'locked'
}

export default function Pathway() {
  const { t } = useTranslation()
  const lang = useStore((s) => s.lang)
  const [lessons, setLessons] = useState([])
  const [progress, setProgress] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [{ data: l }, { data: p }] = await Promise.all([
          client.get('/lessons'),
          client.get('/progress'),
        ])
        setLessons(l)
        setProgress(p)
      } catch {
        setError(t('common.error'))
      } finally {
        setLoading(false)
      }
    }
    fetchAll()
  }, [t])

  const completedIds = new Set(progress.filter((p) => p.completed).map((p) => p.lesson_id))

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-gray-400">
        {t('common.loading')}
      </div>
    )
  }

  if (error) {
    return <p className="text-center text-red-400 py-10">{error}</p>
  }

  return (
    <div className="py-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-1">{t('pathway.title')}</h1>
      <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">{t('pathway.subtitle')}</p>

      <div className="space-y-3">
        {lessons.map((lesson) => (
          <LessonNode
            key={lesson.id}
            lesson={lesson}
            status={computeStatus(lesson, completedIds, lessons)}
            lang={lang}
          />
        ))}
      </div>
    </div>
  )
}
