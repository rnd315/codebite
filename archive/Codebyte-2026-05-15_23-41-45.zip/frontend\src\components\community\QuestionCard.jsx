import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { ChevronDown, ChevronUp, MessageCircle } from 'lucide-react'
import client from '../../api/client'
import useStore from '../../store/useStore'
import AnswerCard from './AnswerCard'
import AnswerForm from './AnswerForm'
import Card from '../ui/Card'

export default function QuestionCard({ question, onAnswerAccepted }) {
  const { t } = useTranslation()
  const user = useStore((s) => s.user)
  const [expanded, setExpanded] = useState(false)
  const [answers, setAnswers] = useState(null) // null = not yet loaded
  const [loading, setLoading] = useState(false)

  const toggle = async () => {
    if (!expanded && answers === null) {
      setLoading(true)
      try {
        const { data } = await client.get(`/community/questions/${question.id}/answers`)
        setAnswers(data)
      } finally {
        setLoading(false)
      }
    }
    setExpanded((p) => !p)
  }

  const handlePostAnswer = async (body) => {
    const { data } = await client.post(`/community/answers/${question.id}`, { body })
    setAnswers((prev) => [...(prev ?? []), data])
  }

  const handleAccept = async (answerId) => {
    const { data } = await client.patch(`/community/answers/${answerId}/accept`)
    setAnswers((prev) => prev.map((a) => (a.id === answerId ? data : a)))
    onAnswerAccepted?.()
  }

  return (
    <Card className="overflow-hidden">
      <button
        onClick={toggle}
        className="w-full text-left p-4 flex items-start gap-3 hover:bg-gray-50 dark:hover:bg-dark-border/30 transition-colors"
      >
        <MessageCircle size={18} className="flex-shrink-0 mt-0.5 text-neon-cyan" />
        <div className="flex-1 min-w-0">
          <p className="text-gray-900 dark:text-white text-sm">{question.body}</p>
          <p className="text-xs text-gray-400 mt-1">
            {t('community.postedBy')} <span className="font-medium">{question.author_username}</span>
            {' · '}
            <span className="inline-flex items-center gap-0.5">
              {question.answer_count} {t('community.answers')}
            </span>
          </p>
        </div>
        {expanded ? (
          <ChevronUp size={16} className="flex-shrink-0 text-gray-400" />
        ) : (
          <ChevronDown size={16} className="flex-shrink-0 text-gray-400" />
        )}
      </button>

      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-gray-100 dark:border-dark-border pt-3">
          {loading && (
            <p className="text-sm text-gray-400">{t('common.loading')}</p>
          )}
          {answers !== null && answers.length === 0 && (
            <p className="text-sm text-gray-400">{t('community.noAnswers')}</p>
          )}
          {answers?.map((a) => (
            <AnswerCard
              key={a.id}
              answer={a}
              questionAuthorId={question.user_id}
              onAccept={handleAccept}
            />
          ))}
          <AnswerForm onSubmit={handlePostAnswer} />
        </div>
      )}
    </Card>
  )
}
