import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Lock, CheckCircle2, ChevronRight } from 'lucide-react'
import Badge from '../ui/Badge'

const DIFFICULTY_KEYS = { 1: 'easy', 2: 'medium', 3: 'hard' }

export default function LessonNode({ lesson, status, lang }) {
  const { t } = useTranslation()
  const navigate = useNavigate()

  const isLocked = status === 'locked'
  const isCompleted = status === 'completed'
  const isAvailable = status === 'available'

  const title = lang === 'ro' ? lesson.title_ro : lesson.title_en
  const diffKey = DIFFICULTY_KEYS[lesson.difficulty] ?? 'easy'

  const handleClick = () => {
    if (!isLocked) navigate(`/lesson/${lesson.slug}`)
  }

  return (
    <button
      onClick={handleClick}
      disabled={isLocked}
      className={`
        w-full text-left flex items-center gap-4 p-4 rounded-2xl border transition-all duration-200
        ${isLocked
          ? 'bg-gray-100 dark:bg-dark-card border-gray-200 dark:border-dark-border opacity-60 cursor-not-allowed'
          : isCompleted
          ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700/50 hover:border-green-400'
          : 'bg-white dark:bg-dark-card border-gray-200 dark:border-dark-border hover:border-neon-cyan hover:shadow-lg dark:hover:shadow-neon-cyan/10 neon-border cursor-pointer'
        }
      `}
    >
      {/* Icon */}
      <div
        className={`
          flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg
          ${isLocked
            ? 'bg-gray-200 dark:bg-dark-border text-gray-400'
            : isCompleted
            ? 'bg-green-100 dark:bg-green-800/40 text-green-500'
            : 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/50'
          }
        `}
      >
        {isLocked ? (
          <Lock size={20} />
        ) : isCompleted ? (
          <CheckCircle2 size={22} />
        ) : (
          lesson.order_index
        )}
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-gray-900 dark:text-white truncate">{title}</h3>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <Badge label={lesson.category} type={lesson.category} />
          <Badge
            label={t(`pathway.difficulty.${lesson.difficulty}`)}
            type={diffKey}
          />
          {lesson.has_visualizer && (
            <span className="text-xs text-neon-cyan font-mono">⚡ visualizer</span>
          )}
        </div>
      </div>

      {/* Status label */}
      <div className="flex-shrink-0 flex items-center gap-1 text-sm">
        {isLocked && (
          <span className="text-gray-400 text-xs">{t('pathway.locked')}</span>
        )}
        {isCompleted && (
          <span className="text-green-500 text-xs font-medium">{t('pathway.completed')}</span>
        )}
        {isAvailable && (
          <span className="flex items-center gap-0.5 text-neon-cyan text-xs font-medium">
            {t('pathway.start')} <ChevronRight size={14} />
          </span>
        )}
      </div>
    </button>
  )
}
