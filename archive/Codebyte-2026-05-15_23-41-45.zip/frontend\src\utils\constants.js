export const MAX_LIVES = 5
export const XP_PER_LESSON = 10
export const XP_PER_QUIZ = 5
export const XP_PER_ACCEPTED = 15
export const DEBUG = false
