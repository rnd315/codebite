import Navbar from './Navbar'
import MobileNav from './MobileNav'

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-white dark:bg-dark-bg">
      <Navbar />
      {/* Offset for fixed navbar (56px) + bottom nav on mobile (64px) */}
      <main className="pt-14 pb-16 sm:pb-4 max-w-6xl mx-auto px-4">
        {children}
      </main>
      <MobileNav />
    </div>
  )
}
