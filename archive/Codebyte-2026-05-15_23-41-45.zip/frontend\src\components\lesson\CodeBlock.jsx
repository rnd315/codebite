import useStore from '../../store/useStore'

export default function CodeBlock({ cpp, python }) {
  const codeLang = useStore((s) => s.codeLang)
  const code = codeLang === 'cpp' ? cpp : python
  const label = codeLang === 'cpp' ? 'C++' : 'Python'

  if (!code) return null

  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 dark:border-dark-border">
      <div className="flex items-center justify-between px-4 py-2 bg-gray-100 dark:bg-dark-border text-xs font-mono text-gray-500 dark:text-gray-400">
        <span>{label}</span>
        <button
          onClick={() => navigator.clipboard?.writeText(code)}
          className="hover:text-neon-cyan transition-colors"
        >
          copy
        </button>
      </div>
      <pre className="bg-gray-50 dark:bg-dark-bg p-4 text-sm font-mono text-gray-800 dark:text-gray-200 overflow-x-auto leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  )
}
