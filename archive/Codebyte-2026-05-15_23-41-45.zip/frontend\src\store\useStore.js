import { create } from 'zustand'
import { persist } from 'zustand/middleware'

const useStore = create(
  persist(
    (set) => ({
      // Auth
      user: null,
      token: null,
      setUser: (user) => set({ user }),
      setToken: (token) => set({ token }),
      logout: () =>
        set({ user: null, token: null, lives: 5, streak: 0, xp: 0 }),

      // Gamification state — synced from backend on login/progress
      lives: 5,
      streak: 0,
      xp: 0,
      setLives: (lives) => set({ lives }),
      setStreak: (streak) => set({ streak }),
      setXp: (xp) => set({ xp }),
      syncFromUser: (user) =>
        set({ lives: user.lives, streak: user.streak, xp: user.xp }),

      // Preferences — persisted to localStorage
      theme: 'dark',
      toggleTheme: () =>
        set((s) => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),

      codeLang: 'cpp',
      setCodeLang: (codeLang) => set({ codeLang }),

      lang: 'en',
      setLang: (lang) => set({ lang }),
    }),
    {
      name: 'codebite-store',
      // Only persist token and preferences — user data re-fetched from API
      partialize: (s) => ({
        token: s.token,
        theme: s.theme,
        codeLang: s.codeLang,
        lang: s.lang,
      }),
    }
  )
)

export default useStore
