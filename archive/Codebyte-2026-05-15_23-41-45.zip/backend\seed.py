"""
Seed script — loads lessons from backend/lessons/ and populates the database.
Run from the backend/ directory:

  python seed.py           — insert new lessons, skip existing ones
  python seed.py --update  — insert new + update content of existing lessons

To add a new lesson:
  1. Create a new folder: backend/lessons/NN-slug/
  2. Add meta.json, content_en.md, content_ro.md, quiz.json
  3. Run: python seed.py
"""
import asyncio
import json
import pathlib
import sys
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import select
from database import Base
from models.lesson import Lesson, QuizQuestion

DATABASE_URL = "sqlite+aiosqlite:///./codebite.db"
LESSONS_DIR = pathlib.Path(__file__).parent / "lessons"


async def seed(update: bool = False):
    engine = create_async_engine(DATABASE_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    Session = async_sessionmaker(engine, expire_on_commit=False)
    async with Session() as session:
        for folder in sorted(LESSONS_DIR.iterdir()):
            if not folder.is_dir():
                continue

            meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
            content_en = (folder / "content_en.md").read_text(encoding="utf-8")
            content_ro = (folder / "content_ro.md").read_text(encoding="utf-8")
            quiz = json.loads((folder / "quiz.json").read_text(encoding="utf-8"))

            result = await session.execute(
                select(Lesson).where(Lesson.slug == meta["slug"])
            )
            existing = result.scalar_one_or_none()

            if existing:
                if not update:
                    print(f"  Skipping {meta['slug']} (already exists — use --update to refresh)")
                    continue
                # Update content and metadata in-place
                existing.title_en = meta["title_en"]
                existing.title_ro = meta["title_ro"]
                existing.category = meta["category"]
                existing.difficulty = meta["difficulty"]
                existing.has_visualizer = meta["has_visualizer"]
                existing.content_en = content_en
                existing.content_ro = content_ro
                # Replace quiz questions
                old_qs = await session.execute(
                    select(QuizQuestion).where(QuizQuestion.lesson_id == existing.id)
                )
                for q in old_qs.scalars().all():
                    await session.delete(q)
                lesson_id = existing.id
                print(f"  Updated: {meta['title_en']}")
            else:
                lesson = Lesson(
                    slug=meta["slug"],
                    order_index=meta["order_index"],
                    title_en=meta["title_en"],
                    title_ro=meta["title_ro"],
                    category=meta["category"],
                    difficulty=meta["difficulty"],
                    has_visualizer=meta["has_visualizer"],
                    content_en=content_en,
                    content_ro=content_ro,
                )
                session.add(lesson)
                await session.flush()
                lesson_id = lesson.id
                print(f"  Seeded: {meta['title_en']}")

            for q_data in quiz:
                question = QuizQuestion(
                    lesson_id=lesson_id,
                    question_en=q_data["question_en"],
                    question_ro=q_data["question_ro"],
                    options_json=json.dumps(q_data["options"]),
                    correct_index=q_data["correct_index"],
                    explanation_en=q_data["explanation_en"],
                    explanation_ro=q_data["explanation_ro"],
                )
                session.add(question)

        await session.commit()

    await engine.dispose()
    print("Done. Database seeded successfully.")


if __name__ == "__main__":
    asyncio.run(seed(update="--update" in sys.argv))
