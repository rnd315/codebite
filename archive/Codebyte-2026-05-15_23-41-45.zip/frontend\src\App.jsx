import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import useStore from './store/useStore'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import Pathway from './pages/Pathway'
import Lesson from './pages/Lesson'
import Community from './pages/Community'
import Profile from './pages/Profile'

function ProtectedRoute({ children }) {
  const token = useStore((s) => s.token)
  return token ? children : <Navigate to="/" replace />
}

export default function App() {
  const theme = useStore((s) => s.theme)
  const lang = useStore((s) => s.lang)
  const { i18n } = useTranslation()

  // Sync Tailwind dark class with store
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  // Sync i18n with store
  useEffect(() => {
    if (i18n.language !== lang) {
      i18n.changeLanguage(lang)
    }
  }, [lang, i18n])

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/pathway"
          element={
            <ProtectedRoute>
              <Layout><Pathway /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/lesson/:slug"
          element={
            <ProtectedRoute>
              <Layout><Lesson /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/community"
          element={
            <ProtectedRoute>
              <Layout><Community /></Layout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Layout><Profile /></Layout>
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
