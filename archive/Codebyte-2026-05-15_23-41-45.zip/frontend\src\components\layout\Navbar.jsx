import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Sun, Moon, Globe, LogOut } from 'lucide-react'
import useStore from '../../store/useStore'
import useAuth from '../../hooks/useAuth'
import LivesDisplay from '../gamification/LivesDisplay'
import StreakCounter from '../gamification/StreakCounter'

export default function Navbar() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const { theme, toggleTheme, lang, setLang, codeLang, setCodeLang, user } = useStore()
  const { logout } = useAuth()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const toggleLang = () => setLang(lang === 'en' ? 'ro' : 'en')

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 h-14 bg-white/90 dark:bg-dark-bg/90 border-b border-gray-200 dark:border-dark-border backdrop-blur-sm">
      <div className="max-w-6xl mx-auto h-full px-4 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => navigate('/pathway')}
          className="text-lg font-bold tracking-tight text-neon-cyan hover:brightness-110 transition-all"
        >
          Code<span className="text-white dark:text-white text-gray-900">Bite</span>
        </button>

        {/* Gamification stats */}
        <div className="flex items-center gap-3 sm:gap-5">
          <LivesDisplay />
          <StreakCounter />
          <span className="hidden sm:flex items-center gap-1 text-sm font-medium text-yellow-400">
            ⭐ {useStore((s) => s.xp)}
          </span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Code language toggle */}
          <button
            onClick={() => setCodeLang(codeLang === 'cpp' ? 'python' : 'cpp')}
            className="hidden sm:flex items-center gap-1 text-xs font-mono font-semibold px-2.5 py-1.5 rounded-lg border border-dark-border hover:border-neon-cyan text-gray-400 hover:text-neon-cyan transition-colors"
          >
            {codeLang === 'cpp' ? 'C++' : 'Python'}
          </button>

          {/* Language toggle */}
          <button
            onClick={toggleLang}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-border transition-colors text-gray-500 dark:text-gray-400"
            title={t('common.language')}
          >
            <Globe size={18} />
          </button>

          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-border transition-colors text-gray-500 dark:text-gray-400"
            title={t('common.theme')}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {/* Avatar + logout */}
          {user && (
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-border transition-colors text-gray-500 dark:text-gray-400"
              title={t('nav.logout')}
            >
              <div className="w-7 h-7 rounded-full bg-neon-cyan/20 border border-neon-cyan flex items-center justify-center text-neon-cyan text-xs font-bold">
                {user.username?.[0]?.toUpperCase() ?? '?'}
              </div>
              <LogOut size={14} className="hidden sm:block" />
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
