export default function Card({ children, className = '', ...props }) {
  return (
    <div
      className={`
        bg-white dark:bg-dark-card
        border border-gray-200 dark:border-dark-border
        rounded-xl shadow-sm
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  )
}
