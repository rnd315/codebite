"""
Rebuilds mod01_01_introducere.json.
No emojis. Quiz split by codeLang: quiz.cpp[3] and quiz.python[3].
"""
import json, pathlib

ROOT = pathlib.Path(__file__).parent.parent
OUT  = ROOT / "backend/lessons/mod01_bazele/mod01_01_introducere.json"

pages = {
  "ro": {
    "cpp": {
      "architect": [
        "### Primul tau semnal\n\n"
        "Un program este o **lista de pasi** pe care computerul ii urmeaza in ordine "
        "-- exact ca o reteta de clatite. "
        "Inainte de orice calcule, trebuie sa stie cum sa vorbeasca cu tine. "
        "In C++, comanda care afiseaza text pe ecran se numeste `cout`.",

        "### O regula simpla, dar importanta\n\n"
        "In C++, fiecare instructiune trebuie sa se termine cu `;` (punct si virgula). "
        "Gandeste-te ca este **punctul de la finalul frazei** -- "
        "fara el, computerul nu stie unde se termina ordinul si se blocheaza.",
      ],
      "hacker": [
        "### Misiunea: primul output\n\n"
        "Un program = o lista de comenzi executate una cate una. "
        "Vrei sa afisezi text pe terminal? "
        "In C++, comanda ta este `cout`. Simplu. Direct. Functioneaza. "
        "Scrii, compilezi, rulezi -- apare pe ecran.",

        "### Regula de aur a C++\n\n"
        "`;` la finalul fiecarei linii de cod. Mereu. "
        "Daca uiti, compilatorul se opreste complet -- nimic nu mai merge. "
        "Nicio exceptie, niciun scuze. "
        "Pune-l si treci mai departe.",
      ],
      "socrates": [
        "### O ghicitoare\n\n"
        "Daca vrei sa trimiti un mesaj cuiva, ai nevoie de o metoda de comunicare -- "
        "telefon, hartie, voce... "
        "Computerul nu te aude, dar are un ecran. "
        "Cum crezi ca ai putea sa ii 'vorbesti' prin cod? "
        "Ce comanda ar putea face asta?",

        "### Gandeste-te la o propozitie\n\n"
        "Cand scrii o fraza, cum stii ca s-a terminat? Prin **punct**! "
        "Computerul face acelasi lucru -- in C++, instructiunile se termina cu `;`. "
        "Fara el, computerul nu stie daca ai terminat sau mai urmeaza ceva "
        "si refuza sa ruleze programul.",
      ],
    },
    "python": {
      "architect": [
        "### Primul tau semnal\n\n"
        "Un program este o **lista de pasi** pe care computerul ii urmeaza in ordine "
        "-- exact ca o reteta. "
        "In Python, afisezi text direct cu `print()`. "
        "Scrii, rulezi, si mesajul apare instant pe ecran. "
        "Nicio pregatire speciala necesara.",

        "### Python e mai relaxat\n\n"
        "In Python nu ai nevoie de punct si virgula la finalul liniilor. "
        "Computerul stie ca o instructiune s-a terminat cand **treci la un rand nou**. "
        "Mai simplu, mai curat -- ca si cum ai scrie o lista de sarcini normala.",
      ],
      "hacker": [
        "### Misiunea: primul output\n\n"
        "Un program = comenzi executate una cate una. "
        "In Python afisezi text cu `print()`. "
        "Zero configuratii, zero pregatiri -- "
        "scrii comanda, rulezi fisierul, gata. Output instant pe terminal.",

        "### Python: zero ceremonie\n\n"
        "Niciun `;`, niciun `{}`, nicio configurare. "
        "Treci la rand nou = Python stie ca instructiunea s-a terminat. "
        "Indentarea conteaza -- asta e singura regula stricta. "
        "Rest? Libertate totala.",
      ],
      "socrates": [
        "### O ghicitoare\n\n"
        "Daca vrei sa trimiti un mesaj cuiva, ai nevoie de o metoda de comunicare. "
        "Computerul nu te aude, dar are un ecran. "
        "Cum crezi ca ai putea sa ii 'vorbesti' cu cel mai simplu cod posibil? "
        "Ce comanda ar putea face asta?",

        "### Gandeste-te la un SMS\n\n"
        "Cand trimiti un SMS, nu pui punct la finalul fiecarei fraze. "
        "Apesi ENTER si gata -- mesajul e complet. "
        "Python functioneaza exact la fel: "
        "treci la rand nou si instructiunea e terminata. Simplu ca un SMS.",
      ],
    },
  },
  "en": {
    "cpp": {
      "architect": [
        "### Your First Signal\n\n"
        "A program is a **list of steps** the computer follows in order -- "
        "just like a cooking recipe. "
        "Before any calculations, it needs to know how to talk to you. "
        "In C++, the command that shows text on screen is called `cout`.",

        "### One Simple Rule\n\n"
        "In C++, every instruction must end with `;` (a semicolon). "
        "Think of it as the **period at the end of a sentence** -- "
        "without it, the computer does not know where your command ends "
        "and gets completely confused.",
      ],
      "hacker": [
        "### Mission: First Output\n\n"
        "A program = a list of commands the machine runs one by one. "
        "Want to print text to the terminal? "
        "In C++, your command is `cout`. Simple. Direct. It works. "
        "Write, compile, run -- it appears on screen.",

        "### The Golden Rule of C++\n\n"
        "`;` at the end of every line of code. Always. "
        "Forget it and the compiler stops dead -- nothing runs. "
        "No exceptions, no excuses. "
        "Just put it there and move on.",
      ],
      "socrates": [
        "### A Riddle\n\n"
        "If you want to send a message to someone, you need a way to communicate -- "
        "a phone, paper, your voice... "
        "The computer cannot hear you, but it has a screen. "
        "How do you think you could talk to it through code? "
        "What command might do that?",

        "### Think About a Sentence\n\n"
        "When you write a sentence, how do you know it is over? With a **period**! "
        "The computer does the same thing -- in C++, instructions end with `;`. "
        "Without it, the computer does not know if you are done "
        "and refuses to run the program.",
      ],
    },
    "python": {
      "architect": [
        "### Your First Signal\n\n"
        "A program is a **list of steps** the computer follows in order -- "
        "just like a recipe. "
        "In Python, you display text directly with `print()`. "
        "Write it, run it, and your message appears on screen instantly. "
        "No special setup required.",

        "### Python is More Relaxed\n\n"
        "In Python you do not need a semicolon at the end of each line. "
        "The computer knows an instruction is over when you **start a new line**. "
        "Simpler, cleaner -- like writing a normal to-do list.",
      ],
      "hacker": [
        "### Mission: First Output\n\n"
        "A program = commands executed one by one. "
        "In Python you print text with `print()`. "
        "Zero setup, zero configuration -- "
        "write the command, run the file, done. Instant output on the terminal.",

        "### Python: Zero Ceremony\n\n"
        "No `;`, no `{}`, no configuration. "
        "Go to a new line = Python knows the instruction is done. "
        "Indentation matters -- that is the only strict rule. "
        "Everything else? Total freedom.",
      ],
      "socrates": [
        "### A Riddle\n\n"
        "If you want to send a message to someone, you need a way to communicate. "
        "The computer cannot hear you, but it has a screen. "
        "How do you think you could talk to it with the simplest code possible? "
        "What command might do that?",

        "### Think About a Text Message\n\n"
        "When you text someone, you do not put a period at the end of every sentence. "
        "You just hit ENTER and move on. "
        "Python works exactly the same way -- "
        "new line = instruction complete. Simple as texting.",
      ],
    },
  },
}

cascades = {
  "ro": {
    "cpp": {
      "architect": (
        "### Codul, pas cu pas\n\n"
        "Hai sa vedem cum ii ordonam computerului sa afiseze un mesaj pe ecran:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Salut, lume!" << "\\n";\n'
        '    cout << "Acesta e primul meu program." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**Ce face fiecare linie:**\n"
        "- `#include <iostream>` -- spune computerului 'am nevoie de uneltele pentru afisat pe ecran'\n"
        "- `using namespace std;` -- o scurtatura ca sa nu scriem cod extra de fiecare data\n"
        "- `int main() { }` -- cutia principala in care sta tot codul important\n"
        '- `cout << "Salut!" << "\\n";` -- impinge textul pe ecran; `"\\n"` apasa ENTER automat\n'
        "- `return 0;` -- anunta ca totul a decurs bine\n\n"
        "**Regula de retinut:** Daca uiti `;` la finalul unei linii, "
        "compilatorul se opreste si primesti o eroare. "
        "Pune intotdeauna `;` si vei fi in regula."
      ),
      "hacker": (
        "### Cod. Ruleaza. Done.\n\n"
        "Asta e cel mai simplu program C++ care trimite text pe terminal:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Acces acordat." << "\\n";\n'
        '    cout << "Sistem online." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**Breakdown rapid:**\n"
        "- `#include <iostream>` -- incarci uneltele de output\n"
        "- `int main()` -- de aici porneste executia, fara exceptii\n"
        '- `cout << "text" << "\\n";` -- trimite text pe terminal, `"\\n"` = linie noua\n'
        "- `return 0;` -- iesire curata, cod de succes\n\n"
        "**Trick:** Foloseste `\"\\n\"` in loc de `endl`. Ambele trec la rand nou, "
        "dar `\"\\n\"` e mai rapid in programe cu mult output. "
        "Obisnuieste-te cu el de la inceput."
      ),
      "socrates": (
        "### Descoperi singur ce face fiecare linie\n\n"
        "Citeste codul de mai jos. Inainte sa citesti explicatiile, "
        "incearca sa ghicesti ce face fiecare linie:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Buna ziua!" << "\\n";\n'
        '    cout << "Tocmai am scris primul meu program." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**Hai sa verificam:**\n"
        "- `#include <iostream>` -- fara asta, `cout` nu exista. E ca si cum ai cere pix inainte sa scrii.\n"
        "- `int main()` -- de ce crezi ca se numeste MAIN? Pentru ca e programul principal -- totul porneste de aici.\n"
        '- `cout << "text"` -- `<<` este ca o sageata: impinge textul spre ecran.\n'
        '- `"\\n"` -- de ce e nevoie de el? Incearca sa-l stergi si ruleaza. Ce observi?\n\n'
        "**Insight:** `\"\\n\"` este tasta ENTER din cod. "
        "Fara el, toate mesajele tale ar aparea pe acelasi rand, lipite. "
        "Cand vrei o linie noua in output -- `\"\\n\"` e raspunsul."
      ),
    },
    "python": {
      "architect": (
        "### Codul, pas cu pas\n\n"
        "Hai sa vedem cum ii ordonam computerului sa afiseze un mesaj pe ecran:\n\n"
        "```python\n"
        'print("Salut, lume!")\n'
        'print("Acesta e primul meu program.")\n'
        "```\n\n"
        "**Ce face fiecare linie:**\n"
        "- `print(\"Salut, lume!\")` -- afiseaza textul dintre paranteze direct pe ecran\n"
        "- A doua linie `print(...)` -- afiseaza al doilea mesaj **pe un rand nou** automat\n"
        "- Nu avem nevoie de cutii speciale sau pregatiri -- Python ruleaza de sus in jos\n\n"
        "**Regula de retinut:** Python apasa automat ENTER dupa fiecare `print()`. "
        "Daca vrei ca doua texte sa apara pe acelasi rand, "
        "folosesti `print(\"text1\", \"text2\")` -- le separa cu un spatiu automat."
      ),
      "hacker": (
        "### Cod. Ruleaza. Done.\n\n"
        "Cel mai simplu program Python care trimite text pe terminal:\n\n"
        "```python\n"
        'print("Acces acordat.")\n'
        'print("Sistem online.")\n'
        "```\n\n"
        "**Breakdown rapid:**\n"
        "- `print(\"text\")` -- trimite textul direct pe terminal, gata\n"
        "- Fiecare `print()` = o linie noua in output, automat\n"
        "- Nu compilezi nimic -- rulezi direct cu `python fisier.py`\n\n"
        "**Trick:** Vrei sa afisezi mai multe lucruri pe acelasi rand? "
        "Folosesti `print(\"A\", \"B\", \"C\")` si Python le separa cu spatii. "
        "Vrei separator diferit? `print(\"A\", \"B\", sep=\"-\")` afiseaza `A-B`."
      ),
      "socrates": (
        "### Descoperi singur ce face fiecare linie\n\n"
        "Citeste codul de mai jos. Inainte sa citesti explicatiile, "
        "incearca sa ghicesti ce va aparea pe ecran:\n\n"
        "```python\n"
        'print("Buna ziua!")\n'
        'print("Tocmai am scris primul meu program.")\n'
        "```\n\n"
        "**Hai sa verificam:**\n"
        "- Ce crezi ca afiseaza prima linie? Textul dintre ghilimele -- exact!\n"
        "- De ce apare al doilea mesaj pe un rand nou, fara sa scriem ceva special?\n"
        "  Python face asta automat -- la fel cum ENTER-ul din SMS trimite pe linie noua.\n"
        "- Incearca sa stergi ghilimelele din jurul textului. Ce crezi ca se intampla?\n\n"
        "**Insight:** Ghilimelele din `print()` sunt ca niste rame -- "
        "tot ce e inuntrul lor apare pe ecran exact cum ai scris. "
        "Daca le uiti, Python nu mai stie ca e text si da eroare."
      ),
    },
  },
  "en": {
    "cpp": {
      "architect": (
        "### The Code, Step by Step\n\n"
        "Let us see how we tell the computer to show a message on screen:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Hello, world!" << "\\n";\n'
        '    cout << "This is my first program." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**What each line does:**\n"
        "- `#include <iostream>` -- tells the computer 'I need the tools to display text on screen'\n"
        "- `using namespace std;` -- a shortcut so we do not have to write extra code every time\n"
        "- `int main() { }` -- the main box where all your important code lives\n"
        '- `cout << "Hello!" << "\\n";` -- pushes text to the screen; `"\\n"` presses ENTER automatically\n'
        "- `return 0;` -- announces that everything went fine\n\n"
        "**Rule to remember:** If you forget `;` at the end of a line, "
        "the compiler stops and you get an error. "
        "Always put `;` and you will be fine."
      ),
      "hacker": (
        "### Code. Run. Done.\n\n"
        "This is the simplest C++ program that sends text to the terminal:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Access granted." << "\\n";\n'
        '    cout << "System online." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**Quick breakdown:**\n"
        "- `#include <iostream>` -- loads your output tools\n"
        "- `int main()` -- execution starts here, no exceptions\n"
        '- `cout << "text" << "\\n";` -- sends text to terminal, `"\\n"` = new line\n'
        "- `return 0;` -- clean exit, success code\n\n"
        "**Trick:** Use `\"\\n\"` instead of `endl`. Both move to a new line, "
        "but `\"\\n\"` is faster in programs with lots of output. "
        "Get used to it from the start."
      ),
      "socrates": (
        "### Discover What Each Line Does\n\n"
        "Read the code below. Before reading the explanations, "
        "try to guess what each line does:\n\n"
        "```cpp\n"
        "#include <iostream>\n"
        "using namespace std;\n\n"
        "int main() {\n"
        '    cout << "Good morning!" << "\\n";\n'
        '    cout << "I just wrote my first program." << "\\n";\n'
        "    return 0;\n"
        "}\n"
        "```\n\n"
        "**Let us check:**\n"
        "- `#include <iostream>` -- without this, `cout` does not exist. Like asking for a pen before writing.\n"
        "- `int main()` -- why do you think it is called MAIN? Because it is the main program -- everything starts here.\n"
        '- `cout << "text"` -- `<<` is like an arrow: it pushes text toward the screen.\n'
        '- `"\\n"` -- why is it needed? Try deleting it and run the code. What do you notice?\n\n'
        "**Insight:** `\"\\n\"` is the ENTER key inside your code. "
        "Without it, all your messages would appear on the same line, squished together. "
        "Whenever you want a new line in your output -- `\"\\n\"` is your answer."
      ),
    },
    "python": {
      "architect": (
        "### The Code, Step by Step\n\n"
        "Let us see how we tell the computer to show a message on screen:\n\n"
        "```python\n"
        'print("Hello, world!")\n'
        'print("This is my first program.")\n'
        "```\n\n"
        "**What each line does:**\n"
        "- `print(\"Hello, world!\")` -- displays the text inside the parentheses directly on screen\n"
        "- The second `print(...)` -- shows the next message **on a new line** automatically\n"
        "- No special boxes or setup needed -- Python runs from top to bottom\n\n"
        "**Rule to remember:** Python automatically presses ENTER after each `print()`. "
        "If you want two pieces of text on the same line, "
        "use `print(\"text1\", \"text2\")` -- Python separates them with a space automatically."
      ),
      "hacker": (
        "### Code. Run. Done.\n\n"
        "The simplest Python program that sends text to the terminal:\n\n"
        "```python\n"
        'print("Access granted.")\n'
        'print("System online.")\n'
        "```\n\n"
        "**Quick breakdown:**\n"
        "- `print(\"text\")` -- sends the text straight to the terminal, that is it\n"
        "- Each `print()` = a new line in output, automatically\n"
        "- No compiling -- run directly with `python file.py`\n\n"
        "**Trick:** Want to display multiple things on the same line? "
        "Use `print(\"A\", \"B\", \"C\")` and Python separates them with spaces. "
        "Want a different separator? `print(\"A\", \"B\", sep=\"-\")` outputs `A-B`."
      ),
      "socrates": (
        "### Discover What Each Line Does\n\n"
        "Read the code below. Before reading the explanations, "
        "try to guess what will appear on screen:\n\n"
        "```python\n"
        'print("Good morning!")\n'
        'print("I just wrote my first program.")\n'
        "```\n\n"
        "**Let us check:**\n"
        "- What do you think the first line shows? The text between the quotes -- exactly!\n"
        "- Why does the second message appear on a new line without writing anything special?\n"
        "  Python does this automatically -- just like ENTER in a text message starts a new line.\n"
        "- Try removing the quotes around the text. What do you think happens?\n\n"
        "**Insight:** The quotes in `print()` are like a frame -- "
        "everything inside them appears on screen exactly as you wrote it. "
        "If you forget them, Python does not know it is text and throws an error."
      ),
    },
  },
}

theory = {}
for lang in ("ro", "en"):
    theory[lang] = {}
    for tech in ("cpp", "python"):
        theory[lang][tech] = {}
        for style in ("architect", "hacker", "socrates"):
            theory[lang][tech][style] = {
                "pages":   pages[lang][tech][style],
                "cascade": cascades[lang][tech][style],
            }

# ─── QUIZ — split by codeLang so questions always match selected tech ──────────

quiz = {
  "cpp": [
    {
      "question_ro": "Ce se intampla daca uiti `;` la finalul unei instructiuni in C++?",
      "question_en": "What happens if you forget `;` at the end of an instruction in C++?",
      "options_ro": [
        "Codul se sterge automat",
        "Compilatorul da o eroare -- nu stie unde se termina comanda",
        "Programul ruleaza, dar mai lent",
        "Trece automat la randul urmator",
      ],
      "options_en": [
        "The code deletes itself automatically",
        "The compiler gives an error -- it does not know where the command ends",
        "The program runs, but slower",
        "It automatically moves to the next line",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "Compilatorul citeste codul caracter cu caracter si se asteapta la `;` ca sa stie ca instructiunea s-a terminat. "
        "Fara el, se opreste si iti arata o eroare. Programul nu va rula deloc pana nu repari greseala."
      ),
      "explanation_en": (
        "The compiler reads code character by character and expects `;` to know an instruction is done. "
        "Without it, it stops and shows you an error. The program will not run at all until you fix the mistake."
      ),
    },
    {
      "question_ro": "Ce face caracterul `\\n` inserat intr-un text in C++?",
      "question_en": "What does the character `\\n` do when inserted in text in C++?",
      "options_ro": [
        "Sterge ultimul cuvant din text",
        "Functioneaza ca tasta ENTER -- muta textul urmator pe un rand nou",
        "Face textul sa fie scris cu litere mari",
        "Opreste executia programului",
      ],
      "options_en": [
        "It deletes the last word from the text",
        "It works like the ENTER key -- moves the next text to a new line",
        "It makes the text appear in capital letters",
        "It stops the execution of the program",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "`\\n` este caracterul de linie noua. Ori de cate ori codul il intalneste, cursorul sare la randul urmator -- "
        "exact ca atunci cand apesi ENTER pe tastatura. Fara el, tot textul tau ar aparea lipit pe o singura linie."
      ),
      "explanation_en": (
        "`\\n` is the newline character. Whenever the code encounters it, the cursor jumps to the next line -- "
        "exactly like pressing ENTER on your keyboard. Without it, all your text would appear squished onto a single line."
      ),
    },
    {
      "question_ro": "De ce `\"\\n\"` este de preferat fata de `endl` in C++ cand ai mult output?",
      "question_en": "Why is `\"\\n\"` preferred over `endl` in C++ when you have lots of output?",
      "options_ro": [
        "`endl` scrie doua caractere, `\"\\n\"` scrie doar unul",
        "`endl` goleste si buffer-ul dupa fiecare linie, ceea ce e mai lent",
        "`endl` nu functioneaza pe toate sistemele",
        "Nu exista nicio diferenta intre ele",
      ],
      "options_en": [
        "`endl` writes two characters while `\"\\n\"` writes only one",
        "`endl` also flushes the buffer after each line, which is slower",
        "`endl` does not work on all systems",
        "There is no difference between them",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "`endl` face doua lucruri: adauga `\\n` si forteaza imediat trimiterea datelor pe ecran (flush). "
        "In programe cu mult output, acest flush la fiecare linie incetineste programul. "
        "`\"\\n\"` adauga doar caracterul, fara flush fortat."
      ),
      "explanation_en": (
        "`endl` does two things: adds `\\n` and immediately forces the data to be sent to the screen (flush). "
        "In programs with heavy output, this flush on every line slows things down. "
        "`\"\\n\"` only adds the character, without a forced flush."
      ),
    },
  ],
  "python": [
    {
      "question_ro": "Cum stie Python ca o instructiune s-a terminat, daca nu folosim `;`?",
      "question_en": "How does Python know an instruction is done if we do not use `;`?",
      "options_ro": [
        "Ghiceste singur pe baza contextului",
        "Prin simpla trecere la o linie noua",
        "Foloseste spatii invizibile speciale",
        "Se uita la lungimea textului",
      ],
      "options_en": [
        "It guesses based on context",
        "By simply moving to a new line",
        "It uses special invisible spaces",
        "It looks at the length of the text",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "In Python, trecerea la un rand nou semnalizeaza ca instructiunea actuala s-a terminat. "
        "E ca si cum ai apasa ENTER la finalul unui SMS -- Python stie ca mesajul e complet."
      ),
      "explanation_en": (
        "In Python, moving to a new line signals that the current instruction is done. "
        "It is like pressing ENTER at the end of a text message -- Python knows the message is complete."
      ),
    },
    {
      "question_ro": "Ce se intampla daca scrii `print(salut)` fara ghilimele in Python?",
      "question_en": "What happens if you write `print(salut)` without quotes in Python?",
      "options_ro": [
        "Afiseaza 'salut' exact cum ai scris",
        "Python da eroare sau cauta o variabila numita 'salut'",
        "Afiseaza un spatiu gol",
        "Programul se opreste si reporneste",
      ],
      "options_en": [
        "It prints 'salut' exactly as you wrote it",
        "Python gives an error or looks for a variable named 'salut'",
        "It prints an empty space",
        "The program stops and restarts",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "Fara ghilimele, Python crede ca `salut` este numele unei variabile, nu un text. "
        "Daca variabila nu exista, primesti `NameError: name 'salut' is not defined`. "
        "Textul pe care vrei sa il afisezi trebuie intotdeauna pus intre ghilimele."
      ),
      "explanation_en": (
        "Without quotes, Python thinks `salut` is the name of a variable, not a text string. "
        "If the variable does not exist, you get `NameError: name 'salut' is not defined`. "
        "Text you want to display must always be placed inside quotes."
      ),
    },
    {
      "question_ro": "Cum afisezi 'A' si 'B' pe acelasi rand, separate printr-o liniuta, in Python?",
      "question_en": "How do you print 'A' and 'B' on the same line, separated by a dash, in Python?",
      "options_ro": [
        "`print(\"A\" + \"B\")`",
        "`print(\"A\", \"B\", sep=\"-\")`",
        "`print(\"A\", \"B\", end=\"-\")`",
        "`print(\"A-\" + \"B-\")`",
      ],
      "options_en": [
        "`print(\"A\" + \"B\")`",
        "`print(\"A\", \"B\", sep=\"-\")`",
        "`print(\"A\", \"B\", end=\"-\")`",
        "`print(\"A-\" + \"B-\")`",
      ],
      "correctAnswerIndex": 1,
      "explanation_ro": (
        "Parametrul `sep` controleaza ce apare intre argumentele lui `print()`. "
        "`sep=\"-\"` pune o liniuta intre 'A' si 'B', rezultand `A-B`. "
        "`end` controleaza ce apare la finalul intregului print, nu intre elemente."
      ),
      "explanation_en": (
        "The `sep` parameter controls what appears between the arguments of `print()`. "
        "`sep=\"-\"` puts a dash between 'A' and 'B', resulting in `A-B`. "
        "`end` controls what appears at the very end of the print, not between elements."
      ),
    },
  ],
}

data = {
    "id": "mod01_01",
    "titleKey": "lessons.mod01_01",
    "interactiveComponent": "MissionKernelCout",
    "theory": theory,
    "quiz": quiz,
}

out = json.dumps(data, ensure_ascii=False, indent=2)
OUT.write_text(out, encoding="utf-8")
print(f"Written {len(out):,} bytes")

parsed = json.loads(out)
assert isinstance(parsed["quiz"], dict), "quiz must be a dict keyed by tech"
assert set(parsed["quiz"].keys()) == {"cpp", "python"}
assert len(parsed["quiz"]["cpp"]) == 3
assert len(parsed["quiz"]["python"]) == 3
for lang in ("ro", "en"):
    for tech in ("cpp", "python"):
        for style in ("architect", "hacker", "socrates"):
            b = parsed["theory"][lang][tech][style]
            assert len(b["pages"]) == 2 and b["cascade"], f"{lang}/{tech}/{style}"
print("Valid -- no emojis, quiz split by codeLang, 12 theory variants")
