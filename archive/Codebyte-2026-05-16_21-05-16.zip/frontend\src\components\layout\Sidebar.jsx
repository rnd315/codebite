import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Zap, Users, Terminal } from 'lucide-react'

const PLACEHOLDER_HELPERS = [
  { name: 'Maria', xp: 328 },
  { name: 'Jin', xp: 285 },
  { name: 'Sofia', xp: 218 },
]

export default function Sidebar({ completedToday = 0, latestQuestion = null }) {
  const navigate = useNavigate()
  const { t } = useTranslation()

  return (
    <div className="hidden lg:flex flex-col gap-4 w-72 flex-shrink-0">
      {/* Daily Quest */}
      <div className="bg-dark-card border border-dark-border rounded-2xl p-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Zap size={13} className="text-neon-cyan" />
            <span className="text-sm font-semibold text-white">{t('sidebar.dailyQuest')}</span>
          </div>
          <span className="text-xs font-mono text-gray-600">{completedToday} / 1</span>
        </div>
        <p className="text-xs text-gray-500 mb-3">{t('sidebar.questGoal')}</p>
        <div className="h-1 bg-dark-border rounded-full overflow-hidden">
          <div
            className="h-full bg-neon-cyan rounded-full transition-all duration-700"
            style={{ width: `${Math.min(completedToday, 1) * 100}%` }}
          />
        </div>
      </div>

      {/* Top debuggers leaderboard */}
      <div className="bg-dark-card border border-dark-border rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Users size={13} className="text-purple-400" />
          <span className="text-sm font-semibold text-white">{t('sidebar.topDebuggers')}</span>
        </div>
        <div className="space-y-3">
          {PLACEHOLDER_HELPERS.map((helper, i) => (
            <div key={helper.name} className="flex items-center gap-3">
              <span className="text-[10px] font-mono text-gray-600 w-4 flex-shrink-0">
                0{i + 1}
              </span>
              <span className="flex-1 text-sm text-gray-200">{helper.name}</span>
              <span className="text-xs font-mono text-neon-cyan">+{helper.xp}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Debugger's Guild community preview */}
      <div className="bg-dark-card border border-dark-border rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Terminal size={13} className="text-neon-cyan" />
          <span className="text-sm font-semibold text-white">{t('sidebar.latestCommunity')}</span>
        </div>
        {latestQuestion ? (
          <>
            <p className="text-[10px] font-mono text-neon-cyan/70 uppercase tracking-wider mb-1.5">
              $ {latestQuestion.author_username}:
            </p>
            <p className="text-sm text-gray-300 mb-4 leading-relaxed line-clamp-3 font-mono text-xs">
              {latestQuestion.body}
            </p>
          </>
        ) : (
          <p className="text-sm text-gray-600 mb-4 font-mono text-xs">{t('sidebar.noQuestions')}</p>
        )}
        <button
          onClick={() => navigate('/community')}
          className="w-full flex items-center justify-center gap-2 text-xs font-mono font-semibold text-neon-cyan border border-neon-cyan/30 rounded-xl py-2.5 hover:bg-neon-cyan/10 hover:border-neon-cyan/60 hover:shadow-[0_0_12px_rgba(34,211,238,0.15)] transition-all"
        >
          {t('sidebar.jumpToFeed')} →
        </button>
      </div>
    </div>
  )
}
