import Navbar from './Navbar'
import MobileNav from './MobileNav'

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-dark-bg">
      {/* Dot grid — dark mode only */}
      <div className="fixed inset-0 pointer-events-none dark:dot-grid" style={{ zIndex: 0 }} />
      <Navbar />
      <main className="relative z-10 pt-14 pb-16 sm:pb-4 max-w-7xl mx-auto px-4 sm:px-6">
        {children}
      </main>
      <MobileNav />
    </div>
  )
}
