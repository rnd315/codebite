import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import client from '../api/client'
import useStore from '../store/useStore'
import MacroModule from '../components/pathway/MacroModule'
import HeroBanner from '../components/layout/HeroBanner'
import Sidebar from '../components/layout/Sidebar'
import { MODULES } from '../utils/constants'

function computeModuleStatus(modIndex, lessons, completedIds) {
  const mod = MODULES[modIndex]
  const modLessons = lessons.filter((l) => mod.categories.includes(l.category))
  if (modLessons.length === 0) return 'locked'

  const allDone = modLessons.every((l) => completedIds.has(l.id))
  if (allDone) return 'completed'

  if (modIndex === 0) return 'active'

  const prevMod = MODULES[modIndex - 1]
  const prevLessons = lessons.filter((l) => prevMod.categories.includes(l.category))
  const prevDone = prevLessons.length > 0 && prevLessons.every((l) => completedIds.has(l.id))
  return prevDone ? 'active' : 'locked'
}

export default function Pathway() {
  const { t } = useTranslation()
  const lang = useStore((s) => s.lang)
  const [lessons, setLessons] = useState([])
  const [progress, setProgress] = useState([])
  const [latestQuestion, setLatestQuestion] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [{ data: l }, { data: p }] = await Promise.all([
          client.get('/lessons'),
          client.get('/progress'),
        ])
        setLessons(l)
        setProgress(p)
        client.get('/community/questions').then(({ data: q }) => {
          if (q.length > 0) setLatestQuestion(q[0])
        }).catch(() => {})
      } catch {
        setError(t('common.error'))
      } finally {
        setLoading(false)
      }
    }
    fetchAll()
  }, [t])

  const completedIds = new Set(progress.filter((p) => p.completed).map((p) => p.lesson_id))
  const completedCount = completedIds.size

  const currentLesson =
    lessons.find((l) => !completedIds.has(l.id)) ?? null

  const clearedModules = MODULES.filter((mod) => {
    const modLessons = lessons.filter((l) => mod.categories.includes(l.category))
    return modLessons.length > 0 && modLessons.every((l) => completedIds.has(l.id))
  }).length

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 font-mono text-sm text-slate-600">
        {t('common.loading')}
      </div>
    )
  }

  if (error) {
    return <p className="text-center text-red-400 py-10 text-sm">{error}</p>
  }

  return (
    <div className="py-6">
      <HeroBanner lessons={lessons} completedCount={completedCount} currentLesson={currentLesson} />

      {/* Skill-tree section header */}
      <div className="flex items-center justify-between mb-5 px-1">
        <div className="flex items-center gap-3">
          <span className="text-[9px] font-mono text-slate-500 dark:text-slate-600 tracking-widest">~/</span>
          <span className="text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 tracking-widest uppercase">
            {t('pathway.skillTree')}
          </span>
          <span className="font-mono text-[9px] text-slate-600 dark:text-slate-700">$ tree --macro</span>
        </div>
        <span className="font-mono text-[9px] text-slate-500 dark:text-slate-600 tracking-widest uppercase">
          {t('pathway.cleared')} {String(clearedModules).padStart(2, '0')}/{String(MODULES.length).padStart(2, '0')}
        </span>
      </div>

      <div className="flex gap-6 items-start">
        {/* Macro modules column */}
        <div className="flex-1 min-w-0 space-y-5">
          {MODULES.map((mod, idx) => {
            const modLessons = lessons.filter((l) => mod.categories.includes(l.category))
            const modStatus = computeModuleStatus(idx, lessons, completedIds)
            return (
              <MacroModule
                key={mod.id}
                module={mod}
                lessons={modLessons}
                completedIds={completedIds}
                moduleStatus={modStatus}
                lang={lang}
              />
            )
          })}
        </div>

        {/* Sidebar */}
        <Sidebar completedToday={0} latestQuestion={latestQuestion} />
      </div>
    </div>
  )
}
