import { useNavigate, useLocation } from 'react-router-dom'
import { Sun, Moon, Zap, Users } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'
import useAuth from '../../hooks/useAuth'
import { MAX_TOKENS } from '../../utils/constants'

export default function Navbar() {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { t } = useTranslation()
  const { theme, toggleTheme, lang, setLang, codeLang, setCodeLang, user, lives, streak } = useStore()
  const { logout } = useAuth()

  const handleLogout = () => { logout(); navigate('/') }

  const isLearning = pathname === '/pathway' || pathname.startsWith('/lesson') || pathname.startsWith('/module')
  const isCommunity = pathname === '/community'

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 h-14 bg-slate-100/95 dark:bg-dark-bg/95 border-b border-slate-200 dark:border-dark-border backdrop-blur-sm">
      <div className="max-w-7xl mx-auto h-full px-4 flex items-center justify-between gap-3">

        {/* Logo */}
        <button
          onClick={() => navigate('/pathway')}
          className="flex items-center gap-2 flex-shrink-0 hover:opacity-85 transition-opacity"
        >
          <span className="font-mono font-bold text-base text-neon-cyan dark:text-neon-cyan text-deep-cyan leading-none">
            {'{'}<span className="text-slate-400 dark:text-slate-400">.</span>
            <span className="text-slate-700 dark:text-slate-300">{'}'}</span>
          </span>
          <div className="flex flex-col leading-none">
            <span className="font-mono text-xs font-bold text-slate-800 dark:text-white tracking-wide">codebite</span>
            <span className="font-mono text-[8px] text-slate-400 dark:text-slate-600 tracking-[0.25em] uppercase">red-shell</span>
          </div>
        </button>

        {/* Center: language toggles + nav pills */}
        <div className="hidden md:flex items-center gap-3">
          {/* Code language toggle */}
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-mono text-slate-400 dark:text-slate-600 uppercase tracking-widest">LANG</span>
            <div className="flex border border-slate-200 dark:border-dark-border rounded-lg overflow-hidden">
              <button
                onClick={() => setCodeLang('cpp')}
                className={`px-2.5 py-1 text-xs font-mono font-semibold transition-colors ${
                  codeLang === 'cpp'
                    ? 'bg-neon-cyan/15 text-neon-cyan dark:text-neon-cyan text-deep-cyan'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >C++</button>
              <button
                onClick={() => setCodeLang('python')}
                className={`px-2.5 py-1 text-xs font-mono font-semibold transition-colors border-l border-slate-200 dark:border-dark-border ${
                  codeLang === 'python'
                    ? 'bg-neon-cyan/15 text-neon-cyan dark:text-neon-cyan text-deep-cyan'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >Python</button>
            </div>
          </div>

          {/* UI language toggle */}
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-mono text-slate-400 dark:text-slate-600 uppercase tracking-widest">UI</span>
            <div className="flex border border-slate-200 dark:border-dark-border rounded-lg overflow-hidden">
              <button
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 text-xs font-mono font-semibold transition-colors ${
                  lang === 'en'
                    ? 'bg-neon-cyan/15 text-deep-cyan dark:text-neon-cyan'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >EN</button>
              <button
                onClick={() => setLang('ro')}
                className={`px-2.5 py-1 text-xs font-mono font-semibold transition-colors border-l border-slate-200 dark:border-dark-border ${
                  lang === 'ro'
                    ? 'bg-neon-cyan/15 text-deep-cyan dark:text-neon-cyan'
                    : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                }`}
              >RO</button>
            </div>
          </div>

          {/* Navigation pills */}
          <div className="flex items-center bg-slate-200 dark:bg-dark-card border border-slate-300 dark:border-dark-border rounded-full p-1 gap-0.5">
            <button
              onClick={() => navigate('/pathway')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                isLearning
                  ? 'bg-deep-cyan dark:bg-neon-cyan text-white dark:text-dark-bg'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              <Zap size={11} /> {t('nav.learning')}
            </button>
            <button
              onClick={() => navigate('/community')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                isCommunity
                  ? 'bg-deep-cyan dark:bg-neon-cyan text-white dark:text-dark-bg'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              <Users size={11} /> {t('nav.guild')}
            </button>
          </div>
        </div>

        {/* Right: Uptime + Tokens + controls */}
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <div className="hidden sm:flex items-center gap-3 font-mono text-xs font-bold">
            <span className="flex items-center gap-1 text-amber-500 dark:text-amber-400">
              ⚡ <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 tracking-widest mr-0.5">UPTIME</span>{streak}d
            </span>
            <span className="flex items-center gap-1 text-cyan-600 dark:text-neon-cyan">
              💠 <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 tracking-widest mr-0.5">TOKENS</span>{lives}/{MAX_TOKENS}
            </span>
          </div>

          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-lg bg-slate-200/60 dark:bg-dark-card hover:bg-slate-300 dark:hover:bg-dark-border transition-colors text-amber-500 dark:text-slate-400 hover:text-amber-600 dark:hover:text-slate-200 border border-slate-200 dark:border-dark-border"
            title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
          >
            {theme === 'dark' ? <Moon size={15} /> : <Sun size={15} />}
          </button>

          {user && (
            <button onClick={handleLogout} className="relative group" title="Logout">
              <div className="w-8 h-8 rounded-full bg-neon-cyan/10 border border-neon-cyan/40 flex items-center justify-center text-deep-cyan dark:text-neon-cyan text-sm font-bold hover:border-neon-cyan transition-colors">
                {user.username?.[0]?.toUpperCase() ?? '?'}
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-yellow-400 border-2 border-slate-100 dark:border-dark-bg" />
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
