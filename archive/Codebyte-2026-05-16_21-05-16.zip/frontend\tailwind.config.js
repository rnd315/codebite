/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Dark mode surfaces (slate-950 / slate-900 / slate-700)
        dark: {
          bg: '#020617',
          card: '#0f172a',
          border: '#334155',
        },
        // Neon accents — dark mode primary palette
        neon: {
          cyan: '#22d3ee',    // cyan-400
          purple: '#c084fc',  // purple-400
          green: '#34d399',   // emerald-400
        },
        // Deep tones — light mode primary palette
        deep: {
          cyan: '#0e7490',    // cyan-700
          indigo: '#4338ca',  // indigo-700
        },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
