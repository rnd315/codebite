import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Lock, Terminal, CheckCircle2 } from 'lucide-react'

function ServerRackPanel({ count, completedCount, isActive, isCompleted }) {
  const slots = Array.from({ length: 5 }, (_, i) => i)
  return (
    <div className="flex-shrink-0 w-28 hidden sm:flex flex-col gap-0">
      <div className="flex justify-between text-[8px] font-mono text-slate-600 mb-1.5 tracking-wider">
        <span>1U · SLOTS</span>
        <span>{isCompleted ? 'DONE' : isActive ? 'ONLINE' : '——'}</span>
      </div>
      {slots.map((i) => {
        const filled = i < completedCount
        const active = i === completedCount && isActive
        return (
          <div key={i} className="flex items-center gap-1.5 py-0.5">
            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
              filled ? 'bg-neon-green' : active ? 'bg-neon-cyan animate-pulse' : 'bg-slate-700'
            }`} />
            <div className={`flex-1 h-px ${
              filled ? 'bg-neon-green/40' : active ? 'bg-neon-cyan/30' : 'bg-slate-800'
            }`} />
            <span className="text-[8px] font-mono text-slate-700 w-4 text-right">
              {String(i).padStart(2, '0')}
            </span>
          </div>
        )
      })}
    </div>
  )
}

export default function MacroModule({ module, lessons, completedIds, moduleStatus, lang }) {
  const navigate = useNavigate()
  const { t } = useTranslation()

  const isActive = moduleStatus === 'active'
  const isCompleted = moduleStatus === 'completed'
  const isLocked = moduleStatus === 'locked'

  const completedCount = lessons.filter((l) => completedIds.has(l.id)).length
  const xpTotal = lessons.length * 10
  const eta = Math.ceil(lessons.length * 0.25)

  const borderClass = isActive
    ? 'border-neon-cyan/50 shadow-[0_0_25px_rgba(34,211,238,0.1)]'
    : isCompleted
    ? 'border-neon-green/30'
    : 'border-dark-border'

  return (
    <div className={`relative overflow-hidden rounded-xl border bg-dark-card transition-all ${borderClass}`}>
      {/* Fog of war overlay for locked modules */}
      {isLocked && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 backdrop-blur-[2px] bg-slate-950/75">
          <Lock size={32} className="text-slate-600" />
          <span className="font-mono text-[10px] text-slate-600 uppercase tracking-[0.2em]">
            {t('module.lockedMessage')}
          </span>
        </div>
      )}

      <div className="p-6">
        {/* Top bar: RACK badge + status badge */}
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono text-[9px] text-slate-600 tracking-widest uppercase">
            RACK / {module.id.toUpperCase()}
          </span>
          <div>
            {isActive && (
              <span className="font-mono text-[10px] px-2 py-0.5 rounded border border-neon-cyan/40 bg-neon-cyan/10 text-neon-cyan tracking-widest">
                ✦ ACTIVE
              </span>
            )}
            {isCompleted && (
              <span className="font-mono text-[10px] px-2 py-0.5 rounded border border-neon-green/40 bg-neon-green/10 text-neon-green tracking-widest">
                ✓ COMPLETE
              </span>
            )}
            {isLocked && (
              <span className="font-mono text-[10px] px-2 py-0.5 rounded border border-slate-700 bg-slate-800/50 text-slate-600 tracking-widest">
                ⊘ LOCKED
              </span>
            )}
          </div>
        </div>

        {/* Main content row */}
        <div className="flex items-start gap-4">
          {/* Left: module info + lessons */}
          <div className="flex-1 min-w-0">
            {/* Module label */}
            <h2 className={`font-mono text-lg font-bold leading-tight mb-0.5 ${isLocked ? 'text-slate-600' : 'text-white'}`}>
              {module.label}
            </h2>
            <p className={`text-xs mb-3 ${isLocked ? 'text-slate-700' : 'text-slate-500'}`}>
              {module.subtitle}
            </p>

            {/* Stats row */}
            <div className={`flex items-center gap-4 font-mono text-xs mb-4 ${isLocked ? 'text-slate-700' : 'text-slate-500'}`}>
              <span>UNITS <strong className={isLocked ? 'text-slate-600' : 'text-slate-300'}>{lessons.length}</strong></span>
              <span>XP <strong className={isLocked ? 'text-slate-600' : 'text-slate-300'}>{xpTotal.toLocaleString()}</strong></span>
              <span>ETA <strong className={isLocked ? 'text-slate-600' : 'text-slate-300'}>{eta}h</strong></span>
            </div>

            {/* Lesson list */}
            <div className="space-y-1.5 mb-4">
              {lessons.map((lesson) => {
                const done = completedIds.has(lesson.id)
                const title = lang === 'ro' ? lesson.title_ro : lesson.title_en
                return (
                  <div key={lesson.id} className="flex items-center gap-2.5">
                    <span className={`text-sm flex-shrink-0 ${done ? 'text-neon-green' : isLocked ? 'text-slate-700' : 'text-slate-600'}`}>
                      {done ? '●' : '○'}
                    </span>
                    <span className={`text-sm ${done ? 'text-slate-300' : isLocked ? 'text-slate-700' : 'text-slate-400'}`}>
                      {title}
                    </span>
                    {done && <CheckCircle2 size={12} className="text-neon-green ml-auto flex-shrink-0" />}
                  </div>
                )
              })}
              {lessons.length === 0 && (
                <p className="text-xs text-slate-700 font-mono">// no lessons loaded</p>
              )}
            </div>

            {/* Progress bar */}
            {lessons.length > 0 && (isActive || isCompleted) && (
              <div className="h-1 bg-dark-border rounded-full overflow-hidden mb-4">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${isCompleted ? 'bg-neon-green' : 'bg-neon-cyan'}`}
                  style={{ width: `${(completedCount / lessons.length) * 100}%` }}
                />
              </div>
            )}

            {/* Action button */}
            {(isActive || isCompleted) && (
              <button
                onClick={() => navigate(`/module/${module.slug}`)}
                className={`flex items-center gap-2 font-mono text-sm font-semibold px-4 py-2.5 rounded-lg border transition-all active:scale-95 ${
                  isActive
                    ? 'border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 hover:shadow-[0_0_12px_rgba(34,211,238,0.2)]'
                    : 'border-neon-green/50 text-neon-green hover:bg-neon-green/10'
                }`}
              >
                <Terminal size={13} />
                {isActive ? '> boot_module' : '> review_module'}
              </button>
            )}
          </div>

          {/* Right: server rack visualization */}
          <ServerRackPanel
            count={lessons.length}
            completedCount={Math.min(completedCount, 5)}
            isActive={isActive}
            isCompleted={isCompleted}
          />
        </div>
      </div>
    </div>
  )
}
