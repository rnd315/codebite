import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import useStore from '../../store/useStore'

export default function HeroBanner({ lessons = [], completedCount = 0, currentLesson = null }) {
  const navigate = useNavigate()
  const { t } = useTranslation()
  const { xp, streak, lang } = useStore()

  const currentTitle = currentLesson
    ? (lang === 'ro' ? currentLesson.title_ro : currentLesson.title_en)
    : null

  const handleResume = () => {
    if (currentLesson) navigate(`/lesson/${currentLesson.slug}`)
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border border-dark-border mb-8">
      {/* Layered background */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark-card via-[#0d0a20] to-dark-card" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_90%_at_75%_50%,rgba(109,40,217,0.18),transparent)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_30%_60%_at_10%_80%,rgba(34,211,238,0.06),transparent)]" />
      <div className="absolute inset-0 dot-grid opacity-30" />

      <div className="relative z-10 p-7 sm:p-8 flex flex-col sm:flex-row sm:items-start justify-between gap-6">
        <div className="flex-1 min-w-0">
          {/* Session tag */}
          <div className="flex items-center gap-2 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan animate-pulse" />
            <span className="text-[9px] font-mono text-gray-400 tracking-[0.25em] uppercase">
              {t('hero.session')}
            </span>
          </div>

          {/* Headlines */}
          <h1 className="text-3xl sm:text-4xl font-bold text-white leading-tight">
            &gt; {t('hero.headline1')}
          </h1>
          <h1 className="text-3xl sm:text-4xl font-bold text-neon-cyan leading-tight mb-4">
            {t('hero.headline2')}
          </h1>

          {/* Subtitle */}
          {currentLesson ? (
            <p className="text-sm text-gray-400 mb-6 max-w-lg leading-relaxed">
              {t('hero.progressText', { completed: completedCount, total: lessons.length, title: currentTitle })}
            </p>
          ) : (
            <p className="text-sm text-gray-400 mb-6 max-w-lg leading-relaxed">
              {t('hero.completedText', { total: lessons.length })}
            </p>
          )}

          {/* Stats row */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 border border-dark-border rounded-full px-3 py-1.5 text-[10px] font-mono text-gray-500 bg-dark-bg/40">
              ⚡ {xp.toLocaleString()} {t('hero.xpWeek')}
            </span>
            <span className="flex items-center gap-1.5 border border-dark-border rounded-full px-3 py-1.5 text-[10px] font-mono text-gray-500 bg-dark-bg/40">
              📅 {streak} {t('hero.dayStreak')}
            </span>
            <span className="flex items-center gap-1.5 border border-dark-border rounded-full px-3 py-1.5 text-[10px] font-mono text-gray-500 bg-dark-bg/40">
              💻 {t('hero.tutor')}
            </span>
          </div>
        </div>

        {/* Resume button */}
        {currentLesson && (
          <button
            onClick={handleResume}
            className="flex-shrink-0 self-start sm:self-center flex items-center gap-2 bg-neon-cyan text-dark-bg font-mono font-semibold text-sm px-5 py-2.5 rounded-lg hover:bg-cyan-300 active:scale-95 transition-all shadow-[0_0_20px_rgba(34,211,238,0.3)]"
          >
            &gt;_ {t('hero.resumeBtn')} →
          </button>
        )}
      </div>
    </div>
  )
}
